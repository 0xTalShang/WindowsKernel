#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}

typedef enum _KAPC_ENVIRONMENT {
    OriginalApcEnvironment,
    AttachedApcEnvironment,
    CurrentApcEnvironment,
    InsertApcEnvironment
} KAPC_ENVIRONMENT;
typedef VOID (*PKNORMAL_ROUTINE) (
    IN PVOID NormalContext,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
    );
typedef VOID (*PKKERNEL_ROUTINE) (
    IN struct _KAPC* Apc,
    IN OUT PKNORMAL_ROUTINE* NormalRoutine,
    IN OUT PVOID* NormalContext,
    IN OUT PVOID* SystemArgument1,
    IN OUT PVOID* SystemArgument2
    );
typedef VOID (*PKRUNDOWN_ROUTINE) (
    IN struct _KAPC* Apc);

NTKERNELAPI VOID KeInitializeApc(
    __out PRKAPC Apc,
    __in PRKTHREAD Thread,
    __in KAPC_ENVIRONMENT Environment,
    __in PKKERNEL_ROUTINE KernelRoutine,
    __in_opt PKRUNDOWN_ROUTINE RundownRoutine,
    __in_opt PKNORMAL_ROUTINE NormalRoutine,
    __in_opt KPROCESSOR_MODE ProcessorMode,
    __in_opt PVOID NormalContext
);
NTKERNELAPI BOOLEAN KeInsertQueueApc(
    __inout PRKAPC Apc,
    __in_opt PVOID SystemArgument1,
    __in_opt PVOID SystemArgument2,
    __in KPRIORITY Increment
);

typedef struct _KAPC_INFO
{
    PKAPC kapc;
    KEVENT kevent;//��һ��ͷ
}KAPC_INFO,*PKAPC_INFO;
VOID KERNEL_ROUTINE(
    IN struct _KAPC* Apc,
    IN OUT PKNORMAL_ROUTINE* NormalRoutine,
    IN OUT PVOID* NormalContext,
    IN OUT PVOID* SystemArgument1,
    IN OUT PVOID* SystemArgument2
)
{
    //DbgBreakPoint();
    UNREFERENCED_PARAMETER(Apc);
    UNREFERENCED_PARAMETER(NormalRoutine);
    UNREFERENCED_PARAMETER(SystemArgument1);
    UNREFERENCED_PARAMETER(SystemArgument2);
    // *NormalRoutine= xxxx �ٳ���
    //ȡ����Apc->NormalContext������ȡ��������
    KdPrintEx((77, 0, "KERNEL_ROUTINE NormalContext:%x\n", (ULONG)*NormalContext));
}
VOID NORMAL_ROUTINE(
    IN PVOID NormalContext,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
)
{
    //DbgBreakPoint();
    UNREFERENCED_PARAMETER(SystemArgument1);
    UNREFERENCED_PARAMETER(SystemArgument2);

    KdPrintEx((77, 0, "NORMAL_ROUTINE NormalContext:%x\n", (ULONG)NormalContext));
    PKAPC_INFO info = (PKAPC_INFO)NormalContext;
    KeSetEvent(&info->kevent,0,FALSE);
    if (info)
    {
        ExFreePool(info);
    }
    if (info->kapc)
    {
        ExFreePool(info->kapc);
    }
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
    //DbgBreakPoint();
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
    PKAPC kapc = ExAllocatePool(NonPagedPool,sizeof(KAPC));
    if (!kapc) return 0;
    memset(kapc, 0, sizeof(KAPC));

    PKAPC_INFO info= (PKAPC_INFO)ExAllocatePool(NonPagedPool, sizeof(KAPC_INFO));
    if (!info) return 0;
    info->kapc = kapc;
    KeInitializeEvent(&info->kevent, SynchronizationEvent,FALSE);

    KeInitializeApc(
        kapc,
        KeGetCurrentThread(),
        OriginalApcEnvironment,
        KERNEL_ROUTINE,
        NULL,
        NORMAL_ROUTINE,
        KernelMode,
        info
    );
    BOOLEAN flag=KeInsertQueueApc(
        kapc,
        NULL,
        NULL,
        0
    );
    if (!flag)
    {
        ExFreePool(info);
        ExFreePool(kapc);
    }
    else 
    {
        //FALSE�����������⻽�ѣ�NULL�������޵ȴ�
        KeWaitForSingleObject(&info->kevent, Executive,KernelMode,FALSE,NULL);
    }
    KdPrintEx((77,0,"����ɹ�!\n"));
	return STATUS_SUCCESS;
}
