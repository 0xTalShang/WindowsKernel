#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	HANDLE pid = (HANDLE)0;
	PEPROCESS ep = 0;
	PsLookupProcessByProcessId(pid,&ep);
	if (!ep) return 0;
	ep = (PEPROCESS)((ULONG)ep - 0x18);//�����ں˶���ͷ

	PVOID mem=ExAllocatePool(NonPagedPool, 0x2f0);//eprocess��С��0x2c0
	memcpy(mem, ep, 0x2D8);//0x2c0+0x18
	
	//Ĩ���ں�ͷ


	return STATUS_SUCCESS;
}
