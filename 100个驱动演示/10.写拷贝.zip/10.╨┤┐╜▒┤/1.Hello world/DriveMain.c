#include<ntifs.h>
#include<intrin.h> //R3 R0����
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{

}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	PEPROCESS ep = 0;
	PsLookupProcessByProcessId((HANDLE)392, &ep);//���ҿ�ĳ����
	if (ep)
	{
		KAPC_STATE kApcState = { 0 };
		KeStackAttachProcess(ep, &kApcState);
		//CR0
		ULONG value = __readcr0();
		__writecr0(value & (~0x10000));//Ĩ��
		memset(0x75A92048,0xCC,1);
		__writecr0(value);
		//CR0
		KeUnstackDetachProcess(&kApcState);
	};
	return STATUS_SUCCESS;
}
