﻿#include<windows.h>
#include<iostream>
using namespace std;
#define CODE_INDEX 0x800
#define CT_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,CODE_INDEX,METHOD_BUFFERED,FILE_ANY_ACCESS)
//#define Symbolic_link L"\\??\\SybmolLink"//试用于win7以上版本
#define Symbolic_link L"\\\\.\\SybmolLink"

int main()
{
	HANDLE h_Device=CreateFile(Symbolic_link,
		GENERIC_READ|GENERIC_WRITE,
		0,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if (!h_Device)
	{
		cout << "打开失败！" << endl;
	}
	DWORD inbuf = 0;
	DWORD outbuf = 0;
	DWORD ret_Byte = 0;
	BOOL is=0;
	if (h_Device)
	{
		is = DeviceIoControl(h_Device, CT_TEST, &inbuf, 4, &outbuf, 4, &ret_Byte, 0);
	}
	if (is)
	{
		cout << outbuf << endl;
	}
	system("pause");
	return 0;
}

