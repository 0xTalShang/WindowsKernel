#pragma once
#include"OpcodeTool.h"

char* CharToUper(char* wstr, BOOLEAN isAllocateMemory)
{
    char* ret = NULL;

    if (isAllocateMemory)
    {
        int len = strlen(wstr) + 2;
        ret = ExAllocatePool(PagedPool, len);
        memset(ret, 0, len);
        memcpy(ret, wstr, len - 2);
    }
    else
    {
        ret = wstr;
    }
    _strupr(ret);
    return ret;
}
//����ģ���С
//����ֵΪģ��Ĵ�С
ULONG_PTR QuerySysModule(char* MoudleName, _Out_opt_ ULONG_PTR* module)
{
    RTL_PROCESS_MODULES info;
    ULONG retPro = 0;
    ULONG_PTR moduleSize = 0;



    NTSTATUS ststas = ZwQuerySystemInformation(SystemModuleInformation, &info, sizeof(info), &retPro);
    char* moduleUper = CharToUper(MoudleName, TRUE);

    if (ststas == STATUS_INFO_LENGTH_MISMATCH)
    {
        //���볤��
        ULONG len = retPro + sizeof(RTL_PROCESS_MODULES);
        PRTL_PROCESS_MODULES mem = (PRTL_PROCESS_MODULES)ExAllocatePool(PagedPool, len);
        memset(mem, 0, len);
        ststas = ZwQuerySystemInformation(SystemModuleInformation, mem, len, &retPro);

        if (!NT_SUCCESS(ststas))
        {
            ExFreePool(moduleUper);
            ExFreePool(mem);
            return 0;
        }

        //��ʼ��ѯ

        if (strstr(MoudleName, "ntkrnlpa.exe") || strstr(MoudleName, "ntoskrnl.exe"))
        {
            PRTL_PROCESS_MODULE_INFORMATION ModuleInfo = &(mem->Modules[0]);
            *module = (ULONG_PTR)ModuleInfo->ImageBase;
            moduleSize = ModuleInfo->ImageSize;
        }
        else
        {
            for (ULONG i = 0; i < mem->NumberOfModules; i++)
            {
                PRTL_PROCESS_MODULE_INFORMATION processModule = &mem->Modules[i];
                CharToUper(processModule->FullPathName, FALSE);
                if (strstr(processModule->FullPathName, moduleUper))
                {
                    if (module)
                    {
                        *module = (ULONG_PTR)processModule->ImageBase;

                    }

                    moduleSize = processModule->ImageSize;

                    break;
                }

            }
        }
        ExFreePool(mem);
    }
    ExFreePool(moduleUper);
    return moduleSize;
}

ULONG_PTR FindOpcode(ULONG_PTR DllBase, ULONG Size, Opcode* opcode)
{
	if (opcode->Buffer1 == 0 || opcode->Buffer2 == 0 || opcode->len1 == 0||opcode->len2 == 0)
	{
		return 0;
	}
	ULONG_PTR EndAddr = DllBase + Size;
	ULONG size1 = opcode->len1;
	ULONG size2 = opcode->len2;
	ULONG Offest = opcode->Offest;
	if (!Offest) return 0;
	for (ULONG_PTR i = DllBase;i < EndAddr;i++)
	{
        if (MmIsAddressValid(i) == FALSE)
        {
            continue;
        }
        if (MmIsAddressValid(i + size1) == FALSE)
        {
            continue;
        }
		if (memcmp(i, opcode->Buffer1, size1) == 0)
		{
            KdPrintEx((77, 0, "��ַ:%x\n", i));
			if (memcmp(i+Offest, opcode->Buffer2, size2) == 0)
			{
				return i;
			}
		}
	}
	return 0;
}


