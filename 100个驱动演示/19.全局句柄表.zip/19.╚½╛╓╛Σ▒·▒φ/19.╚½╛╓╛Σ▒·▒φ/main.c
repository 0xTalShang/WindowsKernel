#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	//DbgBreakPoint();
	//PspCidTable
	ULONG_PTR Addr_Func_Ps=(ULONG_PTR)PsLookupProcessByProcessId;
	ULONG_PTR PspCidTable = *(PULONG)*(PULONG)(Addr_Func_Ps + 0x20);
	PULONG_PTR TableCode = (PULONG_PTR)*(PULONG)PspCidTable;
	TableCode = (PULONG_PTR)((ULONG_PTR)TableCode&0xFFFFFFF0);

	int i = 0;
	for (;;i++)
	{
		if (TableCode[i])
		{
			continue;
		}
		break;
	}
	for (int j = 0; j < i; j++)
	{
		PULONG_PTR HANDLE_TABLE_Array = (PULONG_PTR)TableCode[j];
		for (int m = 0; m < 512; m++)
		{
			PULONG32 Object = (PULONG32)(*(PULONG32)((ULONG_PTR)HANDLE_TABLE_Array + m*8));
			Object = (PULONG32)((ULONG_PTR)Object & 0xFFFFFFF8);
			if (!MmIsAddressValid(Object))
			{
				continue;
			}
			//����ͷ
			PULONG32 OBJECT_HEADER = (PULONG32)((ULONG)Object - 0x18);
			//KdPrintEx((77, 0, "dt _OBJECT_HEADER %x\n", OBJECT_HEADER));
			UCHAR TypeIndex = *(PUCHAR)((ULONG)OBJECT_HEADER+0xc);
			if (TypeIndex != 0x7)
			{
				continue;
			}
			ULONG PID = *(PULONG)((ULONG)Object+0x0b4);
			char* Pname= (char*)((ULONG)Object+0x16c);
			KdPrintEx((77, 0, "PID:%d��Name:%s\n", PID, Pname));
		}
	}
	return STATUS_SUCCESS;
}
