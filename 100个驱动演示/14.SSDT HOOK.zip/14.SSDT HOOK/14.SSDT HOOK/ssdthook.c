#pragma once
#include"ssdthook.h"
#include"��ȡ��������.h"

PEPROCESS GetProcessByname(wchar_t* ProcessName) //û�м������ü���
{
	PEPROCESS ep = NULL;
	for (int i = 8; i < 100000; i += 4)
	{
		PEPROCESS eprocess = NULL;
		PsLookupProcessByProcessId((HANDLE)i, &ep);
		if (!eprocess) continue;
		PUNICODE_STRING pname = 0;
		SeLocateProcessImageName(&eprocess, &pname);//�����������ڴ棬Ȼ�󿽱�ImageFileName�ṹ��
		if (wcsstr(pname->Buffer, ProcessName))
		{
			ep = eprocess;
			ExFreePool(pname);
			ObDereferenceObject(eprocess);
			break;
		}
		else
		{
			ExFreePool(pname);
			ObDereferenceObject(eprocess);
		}
	}
	//DbgPrint("���̵�Eprocess��ַΪ:%x", ep);
	return ep;
}

PNtOpenProcess Old_OpenProcess = NULL;

NTSTATUS NTAPI NtOpenProcess_HOOK(
	_Out_ PHANDLE ProcessHandle,
	_In_ ACCESS_MASK DesiredAccess,
	_In_ POBJECT_ATTRIBUTES ObjectAttributes,
	_In_opt_ PCLIENT_ID ClientId)
{
	KdPrintEx((77, 0, "hooked NtOpenProcess!\n"));
	if (!Old_OpenProcess) return 0;
	Old_OpenProcess(ProcessHandle, DesiredAccess, ObjectAttributes, ClientId);
	return 0;
}
typedef struct _SeriverItem
{
	PULONG32 FuncTable;
	ULONG32  Total;
	ULONG32  FuncSize;
	PULONG32 ParamTable;
}SeriverItem, * pSeriverItem;
typedef struct _SSDT
{
	SeriverItem ssdt1;
	SeriverItem ssdt2;
}SSDT, * PSSDT;
EXTERN_C PSSDT KeServiceDescriptorTable;
ULONG_PTR Enum_SSDT_Func(char* HookFuncName,DWORD32* Number)
{
	PEPROCESS ep=GetProcessByname(L"explorer.exe");
	if (!ep) return 0;
	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep,&apc);
	ULONG_PTR add = GetProcAddressR(0x77A90000, HookFuncName, FALSE);
	if (!add) return 0;
	ULONG_PTR Num = *(PULONG_PTR)(add + 1);
	KdPrintEx((77, 0, "�������:%x\n", Num));
	KeUnstackDetachProcess(&apc);
	if (!Number) return 0;
	*Number = Num;
	add = 0;
	ULONG FuncTable = KeServiceDescriptorTable->ssdt1.FuncTable;
	add = *(PULONG32)(FuncTable+ Num*4);
	if (!add) return 0;
	return add;
}

BOOLEAN SSDTHook(ULONG_PTR newFuncAddr,DWORD32 Number)
{
	if (!newFuncAddr || !Number) return FALSE;
	ULONG FuncTable = KeServiceDescriptorTable->ssdt1.FuncTable;
	PHYSICAL_ADDRESS phy=MmGetPhysicalAddress(FuncTable);
	PULONG mem=MmMapIoSpace(phy, PAGE_SIZE, MmCached);
	if (!mem) return FALSE;
	mem[Number] = newFuncAddr;
	//*(PULONG32)(mem+Number*4)= newFuncAddr;
	MmUnmapIoSpace(mem,PAGE_SIZE);
	return TRUE;
}
BOOLEAN SSDTUnHook(ULONG_PTR newFuncAddr,DWORD32 Number)
{
	BOOLEAN Flag = SSDTHook(newFuncAddr, Number);
	return Flag;
}