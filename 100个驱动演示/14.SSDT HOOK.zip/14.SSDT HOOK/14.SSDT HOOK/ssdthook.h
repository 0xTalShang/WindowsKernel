#pragma once
#include<ntifs.h>
typedef NTSTATUS (NTAPI* PNtOpenProcess)(
    _Out_ PHANDLE ProcessHandle,
    _In_ ACCESS_MASK DesiredAccess,
    _In_ POBJECT_ATTRIBUTES ObjectAttributes,
    _In_opt_ PCLIENT_ID ClientId);

NTSTATUS NTAPI NtOpenProcess_HOOK(
    _Out_ PHANDLE ProcessHandle,
    _In_ ACCESS_MASK DesiredAccess,
    _In_ POBJECT_ATTRIBUTES ObjectAttributes,
    _In_opt_ PCLIENT_ID ClientId);

ULONG_PTR Enum_SSDT_Func(char* HookFuncName, DWORD32* Number);
BOOLEAN SSDTHook(ULONG_PTR newFuncAddr, DWORD32 Number);
BOOLEAN SSDTUnHook(ULONG_PTR newFuncAddr, DWORD32 Number);