#pragma once
#include"��ȡ��������.h"
#include"ssdthook.h"
extern PNtOpenProcess Old_OpenProcess;
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	KdPrintEx((77, 0, "Old������ַ:%x\n", Old_OpenProcess));
	SSDTUnHook(Old_OpenProcess, 0xBE);
}


typedef struct _SeriverItem
{
	PULONG32 FuncTable;
	ULONG32  Total;
	ULONG32  FuncSize;
	PULONG32 ParamTable;
}SeriverItem,*pSeriverItem;
typedef struct _SSDT
{
	SeriverItem ssdt1;
	SeriverItem ssdt2;
}SSDT,*PSSDT;
EXTERN_C PSSDT KeServiceDescriptorTable;
EXTERN_C PNtOpenProcess Old_OpenProcess;
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	KdPrintEx((77,0,"FuncTable location:%x\n", KeServiceDescriptorTable->ssdt1.FuncTable));
	KdPrintEx((77, 0, "Total:%x\n", KeServiceDescriptorTable->ssdt1.Total));
	KdPrintEx((77, 0, "FuncSize:%x\n", KeServiceDescriptorTable->ssdt1.FuncSize));
	KdPrintEx((77, 0, "ParamTable:%x\n", KeServiceDescriptorTable->ssdt1.ParamTable));
	//��λShandow SSDT
	//KdPrintEx((77,0,"Shandow FuncTable location:%x\n",KeServiceDescriptorTable.ssdt1.FuncTable+0x40));

	//Ntdll.base 0x77AB0000
	//ULONG_PTR add=GetProcAddressR(0x77950000,"NtOpenProcess",FALSE);
	//KdPrintEx((77, 0, "������ַ:%x\n", add));
	//DbgBreakPoint();
	DWORD32 Num = 0;
	ULONG_PTR Func_OpenProcess=Enum_SSDT_Func("NtOpenProcess",&Num);
	if (!Func_OpenProcess) return 0x999;
	if (!Num) return 0x999;

	Old_OpenProcess = (PNtOpenProcess)Func_OpenProcess;
	BOOLEAN Flag = SSDTHook(NtOpenProcess_HOOK, Num);

	return STATUS_SUCCESS;
}
