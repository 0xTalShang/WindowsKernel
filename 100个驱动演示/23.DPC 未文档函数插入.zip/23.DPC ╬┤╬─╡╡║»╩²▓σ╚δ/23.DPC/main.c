#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}

VOID KeGenericCallDpc(
	__in PKDEFERRED_ROUTINE Routine,
	__in_opt PVOID Context
);

VOID KeSignalCallDpcDone(
	__in PVOID SystemArgument1
);

LOGICAL KeSignalCallDpcSynchronize(
	__in PVOID SystemArgument2
);

VOID DpcCallBack(
	_In_ struct _KDPC* Dpc,
	_In_opt_ PVOID DeferredContext,
	_In_opt_ PVOID SystemArgument1,
	_In_opt_ PVOID SystemArgument2
)
{
	UNREFERENCED_PARAMETER(Dpc);
	UNREFERENCED_PARAMETER(DeferredContext);
	UNREFERENCED_PARAMETER(SystemArgument1);
	UNREFERENCED_PARAMETER(SystemArgument2);
	ULONG number = KeGetCurrentProcessorNumber();
	KdPrintEx((77, 0, "Dpc������������������:%d\n", number));//ע�⺯��IRQL
	KeSignalCallDpcDone(SystemArgument1);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	KeGenericCallDpc(DpcCallBack,NULL);

	return STATUS_SUCCESS;
}
