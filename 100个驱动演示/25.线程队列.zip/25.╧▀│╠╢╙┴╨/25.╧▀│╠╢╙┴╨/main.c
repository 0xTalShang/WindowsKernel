#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}
VOID Callback(
	_In_ PVOID Parameter
)
{
	UNREFERENCED_PARAMETER(Parameter);
	KdPrintEx((77,0,"Call back!\n"));
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);

	PWORK_QUEUE_ITEM work = ExAllocatePool(NonPagedPool,sizeof(WORK_QUEUE_ITEM));
	if (!work) return 0;
	ExInitializeWorkItem(work, Callback,NULL);
	/*typedef _Enum_is_bitflag_ enum _WORK_QUEUE_TYPE {
		CriticalWorkQueue,
		DelayedWorkQueue,
		HyperCriticalWorkQueue,
		NormalWorkQueue,
		BackgroundWorkQueue,
		RealTimeWorkQueue,
		SuperCriticalWorkQueue,
		MaximumWorkQueue,
		CustomPriorityWorkQueue = 32
	} WORK_QUEUE_TYPE;*/
	ExQueueWorkItem(work, CriticalWorkQueue);

	return STATUS_SUCCESS;
}
