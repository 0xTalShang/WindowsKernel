#include<iostream>
#include<windows.h>
#define CODE_INDEX 0x800
#define CT_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,CODE_INDEX,METHOD_BUFFERED,FILE_ANY_ACCESS)
//#define Symbolic_link L"\\??\\SybmolLink"//������win7���ϰ汾
#define Symbolic_link L"\\\\.\\Nul" //�Ӱ���������
using namespace std;
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;
int main()
{
	HANDLE h_Device = 0;
	h_Device = CreateFile(
		Symbolic_link,
		GENERIC_READ | GENERIC_WRITE,
		0,
		0,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		0);
	if (!h_Device)
	{
		cout << "��ʧ�ܣ�" << endl;
		return 0;
	}
	DATA inbuf = { 0 };
	ULONG a = 0;
	DeviceIoControl(h_Device,
		CT_TEST,
		&inbuf,
		sizeof(DATA),
		&inbuf,
		sizeof(DATA),
		&a,
		0);
	cout << inbuf.DATA << endl;
	CloseHandle(h_Device);
	system("pause");
	return 0;
}