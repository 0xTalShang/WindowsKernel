#include"1.h"
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;

NTSTATUS Main_DISPATCH(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp)
{
	PIO_STACK_LOCATION pIrp = IoGetCurrentIrpStackLocation(Irp);
	ULONG Code = pIrp->Parameters.DeviceIoControl.IoControlCode;
	switch (Code)
	{
	case CT_TEST:
	{
		DbgPrint("�ٳֳɹ�\n");
		PDATA pdata=(PDATA)Irp->AssociatedIrp.SystemBuffer;
		pdata->DATA = 0x2;
		break;
	}
	}
	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = sizeof(DATA);//�� ûд���س��� ��û���ǻ�����
	IoCompleteRequest(Irp,0);                //�� ���ǰ����ȸ��ǻ������� ���Ȳ���Ҳ����
	return STATUS_SUCCESS;
}
typedef NTSTATUS (NTAPI* IRP_DISPATCH)(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp);
IRP_DISPATCH pCallBack = 0;
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	PDRIVER_OBJECT Driver_1 = 0;
	Driver_1 = FindDriverObject(L"\\Driver\\Null");
	if (Driver_1 == 0)
	{
		DbgPrint("δ�ҵ�����\n");
		return STATUS_SUCCESS;
	}
	if (pCallBack != 0)
	{
		Driver_1->MajorFunction[IRP_MJ_DEVICE_CONTROL] = pCallBack;
	}
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	PDRIVER_OBJECT Driver_1 = 0;
	Driver_1 = FindDriverObject(L"\\Driver\\Null");
	if (Driver_1 ==0)
	{
		DbgPrint("δ�ҵ�����\n");
		return STATUS_SUCCESS;
	}
	pCallBack = Driver_1->MajorFunction[IRP_MJ_DEVICE_CONTROL];
	Driver_1->MajorFunction[IRP_MJ_DEVICE_CONTROL]= Main_DISPATCH;
	return STATUS_SUCCESS;
}
