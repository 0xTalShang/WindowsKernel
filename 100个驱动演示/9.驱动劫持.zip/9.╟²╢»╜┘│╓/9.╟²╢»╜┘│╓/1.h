#pragma once
#include<ntifs.h>
#define CODE_INDEX 0x800
#define CT_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,CODE_INDEX,METHOD_BUFFERED,FILE_ANY_ACCESS)
NTKERNELAPI NTSTATUS ObReferenceObjectByName(
    __in PUNICODE_STRING ObjectName,
    __in ULONG Attributes,
    __in_opt PACCESS_STATE AccessState,
    __in_opt ACCESS_MASK DesiredAccess,
    __in POBJECT_TYPE ObjectType,
    __in KPROCESSOR_MODE AccessMode,
    __inout_opt PVOID ParseContext,
    __out PVOID* Object
);
extern POBJECT_TYPE* IoDriverObjectType;
PDRIVER_OBJECT FindDriverObject(wchar_t* name)
{
    UNICODE_STRING DriverName;
    RtlInitUnicodeString(&DriverName, name);
    PDRIVER_OBJECT pDriverObject = 0;
    NTSTATUS status = ObReferenceObjectByName(&DriverName, OBJ_CASE_INSENSITIVE, 0, 0, *IoDriverObjectType, KernelMode, 0, &pDriverObject);//δ�ĵ���������
    if (!NT_SUCCESS(status))
    {
        KdPrint(("��������ʧ��"));
        return 0;
    }
    if (pDriverObject)
    {
        ObDereferenceObject(pDriverObject);//���ü���-1������볤�ó��ж����򲻼Ӵ˺�����
    }
    return pDriverObject;
}