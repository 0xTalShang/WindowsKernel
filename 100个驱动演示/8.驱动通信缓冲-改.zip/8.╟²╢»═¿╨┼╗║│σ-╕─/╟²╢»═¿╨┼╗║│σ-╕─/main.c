#include<ntifs.h>
#define CODE_INDEX 0x800
#define CT_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,CODE_INDEX,METHOD_BUFFERED,FILE_ANY_ACCESS)
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	IoDeleteDevice(DriverObject->DeviceObject);
	UNICODE_STRING SYMBOL_NAME = { 0 };
	RtlInitUnicodeString(&SYMBOL_NAME, L"\\??\\FuckSymblo");
	NTSTATUS sta=IoDeleteSymbolicLink(&SYMBOL_NAME);
	if (!NT_SUCCESS(sta))
	{
		DbgPrint("ɾ����������ʧ��");
	}
}

NTSTATUS DEFAULT_DISPATCH(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp)
{
	Irp->IoStatus.Status = STATUS_SUCCESS;
	DbgPrint("�ɹ���/�ر��豸");
	IoCompleteRequest(Irp,0);
	return STATUS_SUCCESS;
}

NTSTATUS Main_DISPATCH(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp)
{
	PIO_STACK_LOCATION pIrp=IoGetCurrentIrpStackLocation(Irp);
	ULONG Control_Code=pIrp->Parameters.DeviceIoControl.IoControlCode;
	ULONG len_In=pIrp->Parameters.DeviceIoControl.InputBufferLength;
	ULONG len_Out=pIrp->Parameters.DeviceIoControl.OutputBufferLength;
	PDATA pdata=(PDATA)Irp->AssociatedIrp.SystemBuffer;
	switch (Control_Code)
	{
	case CT_TEST:
	{
		DbgPrint("���ӳɹ�\n");
		DbgPrint("PDATA.DATA=%d\n",pdata->DATA);
		pdata->DATA = 2;
		Irp->IoStatus.Status = STATUS_SUCCESS;
		Irp->IoStatus.Information = sizeof(DATA);
	}
	}
	IoCompleteRequest(Irp, 0);
	return STATUS_SUCCESS;
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;

	PDEVICE_OBJECT Device_Object = 0;
	UNICODE_STRING Device_Name = {0};
	RtlInitUnicodeString(&Device_Name, L"\\Device\\FuckDevice");
	NTSTATUS sta=IoCreateDevice(
		pDriver,
		0,
		&Device_Name,
		FILE_DEVICE_UNKNOWN,
		FILE_DEVICE_SECURE_OPEN,
		FALSE,
		&Device_Object
		);
	if (!NT_SUCCESS(sta))
	{
		DbgPrint("�����豸����ʧ��");
	}

	UNICODE_STRING SYMBOL_NAME = { 0 };
	RtlInitUnicodeString(&SYMBOL_NAME, L"\\??\\FuckSymblo");
	sta=IoCreateSymbolicLink(&SYMBOL_NAME,&Device_Name);
	if (!NT_SUCCESS(sta))
	{
		DbgPrint("������������ʧ��");
	}

	pDriver->MajorFunction[IRP_MJ_CREATE] = DEFAULT_DISPATCH;
	pDriver->MajorFunction[IRP_MJ_CLOSE] = DEFAULT_DISPATCH;
	pDriver->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Main_DISPATCH;
	//pDriver->Flags |= DO_BUFFERED_IO;
	Device_Object->Flags |= DO_BUFFERED_IO;
	return STATUS_SUCCESS;
}
