#pragma once
#include<ntifs.h>
#include<ntimage.h>
#include<ntstrsafe.h>
typedef struct _RTL_PROCESS_MODULE_INFORMATION {
    HANDLE Section;                 // Not filled in
    PVOID MappedBase;
    PVOID ImageBase;
    ULONG ImageSize;
    ULONG Flags;
    USHORT LoadOrderIndex;
    USHORT InitOrderIndex;
    USHORT LoadCount;
    USHORT OffsetToFileName;
    UCHAR  FullPathName[256];
} RTL_PROCESS_MODULE_INFORMATION, * PRTL_PROCESS_MODULE_INFORMATION;

typedef struct _RTL_PROCESS_MODULES {
    ULONG NumberOfModules;
    RTL_PROCESS_MODULE_INFORMATION Modules[1];//��������
} RTL_PROCESS_MODULES, * PRTL_PROCESS_MODULES;

typedef enum _SYSTEM_INFORMATION_CLASS {
    SystemBasicInformation,
    SystemProcessorInformation,             // obsolete...delete
    SystemPerformanceInformation,
    SystemTimeOfDayInformation,
    SystemPathInformation,
    SystemProcessInformation,
    SystemCallCountInformation,
    SystemDeviceInformation,
    SystemProcessorPerformanceInformation,
    SystemFlagsInformation,
    SystemCallTimeInformation,
    SystemModuleInformation,//ģ����Ϣ
    SystemLocksInformation,
    SystemStackTraceInformation,
    SystemPagedPoolInformation,
    SystemNonPagedPoolInformation,
    SystemHandleInformation,
    SystemObjectInformation,
    SystemPageFileInformation,
    SystemVdmInstemulInformation,
    SystemVdmBopInformation,
    SystemFileCacheInformation,
    SystemPoolTagInformation,
    SystemInterruptInformation,
    SystemDpcBehaviorInformation,
    SystemFullMemoryInformation,
    SystemLoadGdiDriverInformation,
    SystemUnloadGdiDriverInformation,
    SystemTimeAdjustmentInformation,
    SystemSummaryMemoryInformation,
    SystemMirrorMemoryInformation,
    SystemPerformanceTraceInformation,
    SystemObsolete0,
    SystemExceptionInformation,
    SystemCrashDumpStateInformation,
    SystemKernelDebuggerInformation,
    SystemContextSwitchInformation,
    SystemRegistryQuotaInformation,
    SystemExtendServiceTableInformation,
    SystemPrioritySeperation,
    SystemVerifierAddDriverInformation,
    SystemVerifierRemoveDriverInformation,
    SystemProcessorIdleInformation,
    SystemLegacyDriverInformation,
    SystemCurrentTimeZoneInformation,
    SystemLookasideInformation,
    SystemTimeSlipNotification,
    SystemSessionCreate,
    SystemSessionDetach,
    SystemSessionInformation,
    SystemRangeStartInformation,
    SystemVerifierInformation,
    SystemVerifierThunkExtend,
    SystemSessionProcessInformation,
    SystemLoadGdiDriverInSystemSpace,
    SystemNumaProcessorMap,
    SystemPrefetcherInformation,
    SystemExtendedProcessInformation,
    SystemRecommendedSharedDataAlignment,
    SystemComPlusPackage,
    SystemNumaAvailableMemory,
    SystemProcessorPowerInformation,
    SystemEmulationBasicInformation,
    SystemEmulationProcessorInformation,
    SystemExtendedHandleInformation,
    SystemLostDelayedWriteInformation,
    SystemBigPoolInformation,
    SystemSessionPoolTagInformation,
    SystemSessionMappedViewInformation,
    SystemHotpatchInformation,
    SystemObjectSecurityMode,
    SystemWatchdogTimerHandler,
    SystemWatchdogTimerInformation,
    SystemLogicalProcessorInformation,
    SystemWow64SharedInformation,
    SystemRegisterFirmwareTableInformationHandler,
    SystemFirmwareTableInformation,
    SystemModuleInformationEx,
    SystemVerifierTriageInformation,
    SystemSuperfetchInformation,
    SystemMemoryListInformation,
    SystemFileCacheInformationEx,
    MaxSystemInfoClass  // MaxSystemInfoClass should always be the last enum
} SYSTEM_INFORMATION_CLASS;
NTSTATUS NTAPI ZwQuerySystemInformation(
    __in SYSTEM_INFORMATION_CLASS SystemInformationClass,
    __out_bcount_opt(SystemInformationLength) PVOID SystemInformation,
    __in ULONG SystemInformationLength,
    __out_opt PULONG ReturnLength
);

char* CharToUper(char* wstr, BOOLEAN isAllocateMemory)
{
    char* ret = NULL;

    if (isAllocateMemory)
    {
        int len = strlen(wstr) + 2;
        ret = ExAllocatePool(PagedPool, len);
        memset(ret, 0, len);
        memcpy(ret, wstr, len - 2);
    }
    else
    {
        ret = wstr;
    }
    _strupr(ret);
    return ret;
}
//����ֵΪģ��Ĵ�С
ULONG_PTR QuerySysModule(char* MoudleName, _Out_opt_ ULONG_PTR* module)
{
    RTL_PROCESS_MODULES info;
    ULONG retPro = NULL;
    ULONG_PTR moduleSize = 0;



    NTSTATUS ststas = ZwQuerySystemInformation(SystemModuleInformation, &info, sizeof(info), &retPro);
    char* moduleUper = CharToUper(MoudleName, TRUE);

    if (ststas == STATUS_INFO_LENGTH_MISMATCH)
    {
        //���볤��
        ULONG len = retPro + sizeof(RTL_PROCESS_MODULES);
        PRTL_PROCESS_MODULES mem = (PRTL_PROCESS_MODULES)ExAllocatePool(PagedPool, len);
        memset(mem, 0, len);
        ststas = ZwQuerySystemInformation(SystemModuleInformation, mem, len, &retPro);

        if (!NT_SUCCESS(ststas))
        {
            ExFreePool(moduleUper);
            ExFreePool(mem);
            return 0;
        }

        //��ʼ��ѯ

        if (strstr(MoudleName, "ntkrnlpa.exe") || strstr(MoudleName, "ntoskrnl.exe"))
        {
            PRTL_PROCESS_MODULE_INFORMATION ModuleInfo = &(mem->Modules[0]);
            *module = ModuleInfo->ImageBase;
            moduleSize = ModuleInfo->ImageSize;
        }
        else
        {
            for (int i = 0; i < mem->NumberOfModules; i++)
            {
                PRTL_PROCESS_MODULE_INFORMATION processModule = &mem->Modules[i];
                CharToUper(processModule->FullPathName, FALSE);
                if (strstr(processModule->FullPathName, moduleUper))
                {
                    if (module)
                    {
                        *module = processModule->ImageBase;

                    }

                    moduleSize = processModule->ImageSize;

                    break;
                }

            }
        }
        ExFreePool(mem);
    }
    ExFreePool(moduleUper);
    return moduleSize;
}

void CopyImageHeader(PUCHAR fileBuffer, PUCHAR imageBuffer)
{
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)fileBuffer;
    PIMAGE_NT_HEADERS32 pNts = (PIMAGE_NT_HEADERS32)(fileBuffer + pDos->e_lfanew);
    PIMAGE_SECTION_HEADER pSection = IMAGE_FIRST_SECTION(pNts);

    memcpy(imageBuffer, fileBuffer, pNts->OptionalHeader.SizeOfHeaders);
}

void CopyImageSection(PUCHAR fileBuffer, PUCHAR imageBuffer)
{
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)fileBuffer;
    PIMAGE_NT_HEADERS32 pNts = (PIMAGE_NT_HEADERS32)(fileBuffer + pDos->e_lfanew);
    PIMAGE_SECTION_HEADER pSection = IMAGE_FIRST_SECTION(pNts);

    for (int i = 0; i < pNts->FileHeader.NumberOfSections; i++)
    {
        memcpy(imageBuffer + pSection->VirtualAddress,
            fileBuffer + pSection->PointerToRawData, pSection->SizeOfRawData);
        pSection++;
    }
}

typedef struct _IMAGE_RELOC
{
    UINT16	Offset : 12;
    UINT16	Type : 4;			
} IMAGE_RELOC, * PIMAGE_RELOC;
void ReUpdateReloc(PUCHAR image)
{
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)image;
    PIMAGE_NT_HEADERS32 pImageNts = (PIMAGE_NT_HEADERS32)(image + pDos->e_lfanew);
    PIMAGE_DATA_DIRECTORY pDir = &pImageNts->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];


    if (pDir->Size)
    {
        PIMAGE_BASE_RELOCATION relocation = (PIMAGE_BASE_RELOCATION)(image + pDir->VirtualAddress);
        while (relocation->SizeOfBlock)
        {
            PIMAGE_RELOC pImageReloc = (PIMAGE_RELOC)((ULONG)relocation + sizeof(IMAGE_BASE_RELOCATION));

            //�����ж��ٸ�PIMAGE_RELOC�ṹ
            ULONG blockNumber = (relocation->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(USHORT);

            for (int i = 0; i < blockNumber; i++)
            {
                if (pImageReloc[i].Type == IMAGE_REL_BASED_HIGHLOW)
                {
                    //�޸���32λ
                    PULONG address = (image + pImageReloc[i].Offset + relocation->VirtualAddress);
                    ULONG value = *address - pImageNts->OptionalHeader.ImageBase + (ULONG)image;
                    *address = value;
                }

            }

            //������һ��
            relocation = (PIMAGE_BASE_RELOCATION)((ULONG)relocation + relocation->SizeOfBlock);
        }

        pImageNts->OptionalHeader.ImageBase = (ULONG)image;
    }
}

ULONG_PTR ExportTableFuncByName(char* pData, char* funcName)
{
    PIMAGE_DOS_HEADER pHead = (PIMAGE_DOS_HEADER)pData;
    PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(pData + pHead->e_lfanew);
    int numberRvaAndSize = pNt->OptionalHeader.NumberOfRvaAndSizes;
    PIMAGE_DATA_DIRECTORY pDir = (PIMAGE_DATA_DIRECTORY)&pNt->OptionalHeader.DataDirectory[0];
    PIMAGE_EXPORT_DIRECTORY pExport = (PIMAGE_EXPORT_DIRECTORY)(pData + pDir->VirtualAddress);
    ULONG_PTR funcAddr = 0;
    for (int i = 0; i < pExport->NumberOfNames; i++)
    {
        int* funcAddress = pData + pExport->AddressOfFunctions;
        int* names = pData + pExport->AddressOfNames;
        short* fh = pData + pExport->AddressOfNameOrdinals;
        int index = -1;
        char* name = pData + names[i];
        if (strcmp(name, funcName) == 0)
        {
            index = fh[i];
        }
        if (index != -1)
        {
            funcAddr = pData + funcAddress[index];
            break;
        }
    }
    if (!funcAddr)
    {
        KdPrint(("û���ҵ�����%s\r\n", funcName));
    }
    else
    {
        KdPrint(("�ҵ�����%s addr %p\r\n", funcName, funcAddr));
    }
    return funcAddr;
}
VOID ReIAT(PUCHAR image)
{
    //�޸������
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)image;
    PIMAGE_NT_HEADERS32 pImageNts = (PIMAGE_NT_HEADERS32)(image + pDos->e_lfanew);

    PIMAGE_DATA_DIRECTORY pImport = &pImageNts->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    PIMAGE_IMPORT_DESCRIPTOR pImportDesc = (PIMAGE_IMPORT_DESCRIPTOR)(image + pImport->VirtualAddress);
    PIMAGE_THUNK_DATA pNames = NULL;
    PIMAGE_THUNK_DATA pFuncP = NULL;

    BOOLEAN isFiled = FALSE;

    for (; pImportDesc->Name; pImportDesc++)
    {

        PUCHAR  libName = pImportDesc->Name + image;
        ULONG_PTR module = 0, moudleSize = 0;
        if (QuerySysModule(libName, &module))
        {

            pNames = (PIMAGE_THUNK_DATA)(image + pImportDesc->OriginalFirstThunk);
            pFuncP = (PIMAGE_THUNK_DATA)(image + pImportDesc->FirstThunk);

            for (; pNames->u1.ForwarderString; pNames++, pFuncP++)
            {
                PIMAGE_IMPORT_BY_NAME byName = (PIMAGE_IMPORT_BY_NAME)(pNames->u1.AddressOfData + image);
                ULONG_PTR func = ExportTableFuncByName((char*)module, byName->Name);
                if (func)
                {
                    pFuncP->u1.Function = func;
                }
                else
                {
                    isFiled = TRUE;
                    break;
                }
                //image + pNames->
            }
        }
    }

}

typedef NTSTATUS(NTAPI* DriverEntryCallback)(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg);
PVOID NTAPI RtlImageDirectoryEntryToData(
    IN PVOID Base,
    IN BOOLEAN MappedAsImage,
    IN USHORT DirectoryEntry,
    OUT PULONG Size
);
NTSTATUS LoadDriver(PUCHAR buffer)
{
    PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)buffer;
    PIMAGE_NT_HEADERS32 pNts = (PIMAGE_NT_HEADERS32)(buffer + pDos->e_lfanew);
    PIMAGE_SECTION_HEADER pSection = IMAGE_FIRST_SECTION(pNts);

    PHYSICAL_ADDRESS phyLow;
    PHYSICAL_ADDRESS phyhei;
    phyLow.QuadPart = 0;
    phyhei.QuadPart = -1;
    PUCHAR image = NULL;

    int count = 3;
    do
    {
        image = MmAllocateContiguousMemorySpecifyCache(pNts->OptionalHeader.SizeOfImage
            , phyLow, phyhei, phyLow, MmCached);
        if (image) break;
        --count;
    } while (count);

    if (!image) return STATUS_UNSUCCESSFUL;


    CopyImageHeader(buffer, image);
    CopyImageSection(buffer, image);
    ReUpdateReloc(image);
    ReIAT(image);

    pDos = (PIMAGE_DOS_HEADER)image;
    pNts = (PIMAGE_NT_HEADERS32)(image + pDos->e_lfanew);

    //��ȡ����ڵ�
    DriverEntryCallback EntryCall = (DriverEntryCallback)(pNts->OptionalHeader.AddressOfEntryPoint + image);
    ULONG retSize = 0;

    PIMAGE_LOAD_CONFIG_DIRECTORY load = RtlImageDirectoryEntryToData(image, TRUE, 10, &retSize);
    *(PULONG_PTR)load->SecurityCookie += 10;
    EntryCall(NULL, NULL);
    return STATUS_SUCCESS;
    
}

BOOLEAN DeleteRegedit(PUNICODE_STRING pReg)
{
    if (pReg->Buffer == NULL) return FALSE;
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE,pReg->Buffer,L"DisplayName");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE,pReg->Buffer,L"ErrorControl");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE,pReg->Buffer,L"ImagePath");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE,pReg->Buffer,L"Start");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE,pReg->Buffer,L"Type");

    wchar_t StrBuffer[256] = { 0 };
    RtlStringCbPrintfW(StrBuffer,512,L"%ws\\%ws",pReg->Buffer,L"Enum");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE, StrBuffer, L"Count");
   // RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE, StrBuffer, L"INITSTARTFAILED"); ɾ����
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE, StrBuffer, L"NextInstance");
    RtlDeleteRegistryValue(RTL_REGISTRY_ABSOLUTE, StrBuffer, L"0");

    HANDLE pKey = 0;
    OBJECT_ATTRIBUTES ob = { 0 };
    UNICODE_STRING name = { 0 };
    RtlInitUnicodeString(&name, StrBuffer);
    InitializeObjectAttributes(&ob,&name,OBJ_CASE_INSENSITIVE,NULL,NULL);
    NTSTATUS sta=ZwOpenKey(&pKey,KEY_ALL_ACCESS,&ob);
    if (!NT_SUCCESS(sta))
    {
        return FALSE;
    }
    ZwDeleteKey(pKey);
    ZwClose(pKey);

    HANDLE pKey2 = 0;
    OBJECT_ATTRIBUTES ob2 = { 0 };
    InitializeObjectAttributes(&ob2, pReg, OBJ_CASE_INSENSITIVE, NULL, NULL);
    sta = ZwOpenKey(&pKey2, KEY_ALL_ACCESS, &ob2);
    if (!NT_SUCCESS(sta))
    {
        return FALSE;
    }
    ZwDeleteKey(pKey2);
    ZwClose(pKey2);

    return TRUE;
}

BOOLEAN DeleteFile(PUNICODE_STRING pFile)
{
    DbgBreakPoint();
    HANDLE H_File = 0;
    OBJECT_ATTRIBUTES ob = { 0 };
    IO_STATUS_BLOCK Io = { 0 };
    InitializeObjectAttributes(&ob, pFile,OBJ_CASE_INSENSITIVE|OBJ_KERNEL_HANDLE,0,0);
    NTSTATUS sta=ZwCreateFile(
        &H_File,
        FILE_READ_DATA,
        &ob,
        &Io,
        0,//����or���ǵ��ļ��Ĵ�С
        FILE_ATTRIBUTE_NORMAL,
        0,//�����������̶߳���д��ɾ����ռ��
        FILE_OPEN,
        FILE_NON_DIRECTORY_FILE,
        0,
        0
    );
    if (!NT_SUCCESS(sta)) return FALSE;

    PFILE_OBJECT OB_File = 0;
    sta=ObReferenceObjectByHandle(
        H_File,
        FILE_ALL_ACCESS,
        *IoFileObjectType,
        KernelMode,
        &OB_File,
        0
        );
    if (!NT_SUCCESS(sta)) return FALSE;
    OB_File->DeletePending = 0;
    OB_File->DeleteAccess = 1;
    OB_File->SharedDelete = 1;
    OB_File->SectionObjectPointer->DataSectionObject = 0;
    OB_File->SectionObjectPointer->ImageSectionObject = 0;
    OB_File->SectionObjectPointer->SharedCacheMap = 0;
    sta=ZwClose(H_File);
    if (!NT_SUCCESS(sta)) return FALSE;
    sta=ZwDeleteFile(&ob);
    if (!NT_SUCCESS(sta)) return FALSE;
    return TRUE;
}