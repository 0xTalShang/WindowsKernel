#include"1.h"
#include"array.h"
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	//DbgBreakPoint();
	//LoadDriver(hexData);

	//DeleteRegedit(pReg);
    //C:\Users\TalShang\Desktop
	UNICODE_STRING Name_File = { 0 };
	RtlInitUnicodeString(&Name_File,L"\\??\\C:\\Users\\TalShang\\Desktop\\�������� - ����.exe");
	DeleteFile(&Name_File);
	return STATUS_UNSUCCESSFUL;//�Զ�ж��
}
