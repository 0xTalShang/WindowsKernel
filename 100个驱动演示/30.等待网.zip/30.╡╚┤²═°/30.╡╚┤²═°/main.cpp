#include<windows.h>
#include<stdio.h>


HANDLE hEvent;

DWORD ThreadFunc(PVOID CONTEXT)
{
	WaitForSingleObject(hEvent,-1);
	return 0;
}
int main()
{
	hEvent=CreateEventA(NULL,FALSE,FALSE,NULL);
	CreateThread(NULL,NULL,ThreadFunc,NULL,NULL,NULL);
	WaitForSingleObject(hEvent, -1);
	system("pause");
	return 0;
}