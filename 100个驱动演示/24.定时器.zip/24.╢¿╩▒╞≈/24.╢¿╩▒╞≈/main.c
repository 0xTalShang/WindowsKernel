#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}


PKTIMER timer = NULL;

VOID DpcCallBack(
	_In_ struct _KDPC* Dpc,
	_In_opt_ PVOID DeferredContext,
	_In_opt_ PVOID SystemArgument1,
	_In_opt_ PVOID SystemArgument2
)
{
	UNREFERENCED_PARAMETER(SystemArgument1);
	UNREFERENCED_PARAMETER(SystemArgument2);
	ULONG32 num = *(PULONG32)DeferredContext;
	if (num == 0) return;
	KdPrintEx((77,0,"Timer call! ���:%d\n", num));

	LARGE_INTEGER time = { 0 };
	time.QuadPart = -10000 * 3000;//����
	KeSetTimer(timer, time, Dpc);
	num -= 1;
	*(PULONG32)DeferredContext = num;
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	//DPC
	PKDPC dpc = ExAllocatePool(NonPagedPool,sizeof(KDPC));
	if (!dpc) return 0;
	PULONG32 num = ExAllocatePool(NonPagedPool, 4);
	if (!num) return 0;
	*num = 5;
	KeInitializeDpc(dpc,DpcCallBack, num);

	//Timer
	timer= ExAllocatePool(NonPagedPool, sizeof(KTIMER));
	if (!timer) return 0;
	KeInitializeTimer(timer);
	LARGE_INTEGER time = { 0 };
	time.QuadPart = -10000 * 3000;//����
	BOOLEAN flag=KeSetTimer(timer,time,dpc);
	if (!flag) return 0;

	return STATUS_SUCCESS;
}
