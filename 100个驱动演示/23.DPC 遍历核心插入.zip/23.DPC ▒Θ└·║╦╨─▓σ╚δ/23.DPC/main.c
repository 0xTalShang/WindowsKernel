#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}

VOID DpcCallBack(
	_In_ struct _KDPC* Dpc,
	_In_opt_ PVOID DeferredContext,
	_In_opt_ PVOID SystemArgument1,
	_In_opt_ PVOID SystemArgument2
)
{
	UNREFERENCED_PARAMETER(Dpc);
	UNREFERENCED_PARAMETER(DeferredContext);
	UNREFERENCED_PARAMETER(SystemArgument1);
	UNREFERENCED_PARAMETER(SystemArgument2);
	ULONG number = KeGetCurrentProcessorNumber();
	KdPrintEx((77, 0, "Dpc������������������:%d\n", number));//ע�⺯��IRQL
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);

	PKDPC DPC= ExAllocatePool(NonPagedPool,sizeof(KDPC));
	if (!DPC) return STATUS_SUCCESS;

	KeInitializeDpc(DPC, DpcCallBack, NULL);
	for (int i = 0; i < KeNumberProcessors; i++)
	{	
		KeSetTargetProcessorDpc(DPC, (CCHAR)i);//����DPCĿ�����ĺ��ı��
		KeInsertQueueDpc(DPC, NULL, NULL);
	}

	return STATUS_SUCCESS;
}
