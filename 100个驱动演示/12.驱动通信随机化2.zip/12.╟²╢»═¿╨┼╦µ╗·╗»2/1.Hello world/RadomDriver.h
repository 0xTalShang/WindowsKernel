#pragma once
#include<ntifs.h>
#include<ntstrsafe.h>//�����ַ���
#include<ntimage.h>

PUNICODE_STRING Random_Symbolic()
{
	static UNICODE_STRING str_symbolic= { 0 };
	if (str_symbolic.Length != 0)
	{
		return &str_symbolic;
	}
	LARGE_INTEGER time = { 0 };
	KeQuerySystemTime(&time);
	ULONG rand_num1=RtlRandom(&time.LowPart);//�ĸ��ֽڵ����������
	                                        //��λʱ���������
	ULONG rand_num2=RtlRandom(&time.LowPart);
	wchar_t bufstring[100] = { 0 };
	RtlStringCbPrintfW(bufstring,100*sizeof(wchar_t),L"\\??\\%x%x",rand_num1,rand_num2);
	int len = wcslen(bufstring)*2;//wcslen()ȡ�ַ�����Ҳ�����ַ�������
	str_symbolic.Buffer =(PWCH)ExAllocatePool(PagedPool,len+2);
	//��ҳ�ڴ�һ��ɶ���д �Ƿ�ҳ�ڴ�һ���ǿɶ���д��ִ��
	str_symbolic.Length = len;
	str_symbolic.MaximumLength = len + 2;
	memset(str_symbolic.Buffer, 0, len);
	memcpy(str_symbolic.Buffer, bufstring,len);
	memset(bufstring,0,len);
	return &str_symbolic;
}

PUNICODE_STRING Random_Device()
{
	static UNICODE_STRING str_symbolic = { 0 };
	if (str_symbolic.Length != 0)
	{
		return &str_symbolic;
	}
	LARGE_INTEGER time = { 0 };
	KeQuerySystemTime(&time);
	ULONG rand_num = RtlRandom(&time.LowPart);//�ĸ��ֽڵ����������
											//��λʱ���������
	wchar_t bufstring[100] = { 0 };
	RtlStringCbPrintfW(bufstring, 100 * sizeof(wchar_t), L"\\Device\\%x", rand_num);
	int len = wcslen(bufstring) * 2;//wcslen()ȡ�ַ�����Ҳ�����ַ�������
	str_symbolic.Buffer = (PWCH)ExAllocatePool(PagedPool, len + 2);
	//��ҳ�ڴ�һ��ɶ���д �Ƿ�ҳ�ڴ�һ���ǿɶ���д��ִ��
	str_symbolic.Length = len;
	str_symbolic.MaximumLength = len + 2;
	memset(str_symbolic.Buffer, 0, len);
	memcpy(str_symbolic.Buffer, bufstring, len);
	memset(bufstring, 0, len);
	return &str_symbolic;
}

PEPROCESS GetProcessByname(wchar_t* ProcessName) //û�м������ü���
{
	PEPROCESS ep = NULL;
	for (int i = 8; i < 70000; i += 4)
	{
		PEPROCESS eprocess = NULL;
		PsLookupProcessByProcessId((HANDLE)i,&ep);
		if (!eprocess) continue;
		PUNICODE_STRING pname = 0;
		SeLocateProcessImageName(&eprocess,&pname);
		if (wcsstr(pname->Buffer,ProcessName))
		{
			ep = eprocess;
			ExFreePool(pname);
			break;
		}
		else
		{
			ExFreePool(pname);
		}
	}
	DbgPrint("���̵�Eprocess��ַΪ:%x",ep);
	return ep;
}

//ǰ����������ÿ�����ĵ�ַ��Ч��ÿ����������û�����
//0x30 bytes (sizeof)
struct _PEB_LDR_DATA
{
	ULONG Length;                                                           //0x0
	UCHAR Initialized;                                                      //0x4
	VOID* SsHandle;                                                         //0x8
	LIST_ENTRY InLoadOrderModuleList;                               //0xc
	LIST_ENTRY InMemoryOrderModuleList;                             //0x14
	LIST_ENTRY InInitializationOrderModuleList;                     //0x1c
	VOID* EntryInProgress;                                                  //0x24
	UCHAR ShutdownInProgress;                                               //0x28
	VOID* ShutdownThreadId;                                                 //0x2c
};
//0x78 bytes (sizeof)
struct _LDR_DATA_TABLE_ENTRY
{
	struct _LIST_ENTRY InLoadOrderLinks;                                    //0x0
	struct _LIST_ENTRY InMemoryOrderLinks;                                  //0x8
	struct _LIST_ENTRY InInitializationOrderLinks;                          //0x10
	VOID* DllBase;                                                          //0x18
	VOID* EntryPoint;                                                       //0x1c
	ULONG SizeOfImage;                                                      //0x20
	struct _UNICODE_STRING FullDllName;                                     //0x24
	struct _UNICODE_STRING BaseDllName;                                     //0x2c
	ULONG Flags;                                                            //0x34
	USHORT LoadCount;                                                       //0x38
	USHORT TlsIndex;                                                        //0x3a
	union
	{
		struct _LIST_ENTRY HashLinks;                                       //0x3c
		struct
		{
			VOID* SectionPointer;                                           //0x3c
			ULONG CheckSum;                                                 //0x40
		};
	};
	union
	{
		ULONG TimeDateStamp;                                                //0x44
		VOID* LoadedImports;                                                //0x44
	};
	struct _ACTIVATION_CONTEXT* EntryPointActivationContext;                //0x48
	VOID* PatchInformation;                                                 //0x4c
	struct _LIST_ENTRY ForwarderLinks;                                      //0x50
	struct _LIST_ENTRY ServiceTagLinks;                                     //0x58
	struct _LIST_ENTRY StaticLinks;                                         //0x60
	VOID* ContextInformation;                                               //0x68
	ULONG OriginalBase;                                                     //0x6c
	union _LARGE_INTEGER LoadTime;                                          //0x70
};
PVOID NTAPI PsGetProcessPeb(PEPROCESS ep);
PVOID GetDLLBase(PEPROCESS ep, wchar_t* DllName)
{
	PVOID Hmodule = 0;
	if (ep == NULL || DllName[0] == L'\0')
	{
		return 0;
	}
	PVOID peb = PsGetProcessPeb(ep);
	if (!peb)
	{
		return NULL;
	}
	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep,&apc);
	PUCHAR LDR = *(PULONG)((PUCHAR)peb + 0xC);
	if (!LDR) return 0;
	struct _LDR_DATA_TABLE_ENTRY* List=(struct _LDR_DATA_TABLE_ENTRY*)&((struct _PEB_LDR_DATA*)LDR)->InLoadOrderModuleList;
	struct _LDR_DATA_TABLE_ENTRY* Next = List->InLoadOrderLinks.Flink;
	while (List != Next)
	{
		try
		{
			ProbeForRead(Next, 1, 1);
			if (Next->BaseDllName.Length && wcsstr(Next->BaseDllName.Buffer, DllName))
				//��Ҫ�жϵ�ǰ�ڵ��Str�Ƿ���Ч //�ǳ������쳣
			{   //��Щ���û��DLL����
				Hmodule = Next->DllBase;
				break;
			}
		}
		except(1)
		{
			Next = Next->InLoadOrderLinks.Flink;
			continue;
		}
		Next = Next->InLoadOrderLinks.Flink;
	}
	KeUnstackDetachProcess(&apc);
	return Hmodule;
}

VOID EDIT_R3_DLL_DOS(PVOID Dll,PUNICODE_STRING pu,PEPROCESS ep)
{
	//DbgBreakPoint();
	if (Dll == 0||ep==0 ||pu->Length==0)
	{
		DbgPrint("�޸�DOSʧ��\n");
		return;
	}
	KAPC_STATE apc = { 0 };
	wchar_t bufferName[60] = { 0 };
	RtlStringCbPrintfW(bufferName, 60 * 2, L"\\\\.\\%ws", pu->Buffer + 4);
	//KdPrintEx((77,0,"�ַ���:%ws\n", bufferName));

	KeStackAttachProcess(ep, &apc);
	PUCHAR a = (PUCHAR)Dll + sizeof(IMAGE_DOS_HEADER);
	PVOID mem=MmMapIoSpace(MmGetPhysicalAddress(a), 200, MmCached);
	if (!mem)
	{
		DbgPrint("�޸�DOSӳ��ʧ��\n");
		return;
	}
	memset(mem,0, wcslen(bufferName) * 2 + 4);//��R3���ַ�����ȡ�ṩ����
	memcpy(mem, bufferName, wcslen(bufferName) * 2 + 2);
	MmUnmapIoSpace(mem,200);
	KeUnstackDetachProcess(&apc);
}