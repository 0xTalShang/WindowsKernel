#include "FindPESpace.h"
#include "RadomDriver.h"
#define CODE_INDEX 0x800
#define CT_TEST CTL_CODE(FILE_DEVICE_UNKNOWN,CODE_INDEX,METHOD_BUFFERED,FILE_ANY_ACCESS)
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;
NTSTATUS Main_DISPATCH(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp)
{
	PIO_STACK_LOCATION pIrp = IoGetCurrentIrpStackLocation(Irp);
	ULONG Code = pIrp->Parameters.DeviceIoControl.IoControlCode;
	switch (Code)
	{
	case CT_TEST:
	{
		DbgPrint("�ٳֳɹ�\n");
		PDATA pdata = (PDATA)Irp->AssociatedIrp.SystemBuffer;
		pdata->DATA = 0x2;
		break;
	}
	}
	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = sizeof(DATA);//�� ûд���س��� ��û���ǻ�����
	IoCompleteRequest(Irp, 0);                //�� ���ǰ����ȸ��ǻ������� ���Ȳ���Ҳ����
	return STATUS_SUCCESS;
}

//
PUNICODE_STRING pu = NULL;
PUNICODE_STRING Device_NAME = NULL;
//
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	PDRIVER_OBJECT Driver_1 = FindDriverObject(L"\\Driver\\Null");
	if (Driver_1)
	{
	//	IoDeleteDevice(Driver_1->DeviceObject);
		IoDeleteSymbolicLink(pu);
	}
	
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	//DbgBreakPoint();
	//
	PEPROCESS ep=GetProcessByname(L"explorer.exe");
	if (!ep)
	{
		return STATUS_SUCCESS;
	}
	PVOID ntdll = GetDLLBase(ep, L"ntdll.dll");
	if (!ntdll)
	{
		return STATUS_SUCCESS;
	}
	DbgPrint("ntdll��ģ���ַΪ:%p\n", ntdll);
	//
	pDriver->DriverUnload = DRIVERUNLOAD;
	pu = Random_Symbolic();
	Device_NAME = Random_Device();
	DbgPrint("�ַ���Ϊ:%wZ\n", pu);
	//DbgPrint("�豸�����ַ���Ϊ:%wZ", Device_NAME);
	PDRIVER_OBJECT Driver_1 = FindDriverObject(L"\\Driver\\Null");
	if (!Driver_1)
	{
		DbgPrint("Ѱ������ʧ��\n");
		return STATUS_SUCCESS;
	}
	PDEVICE_OBJECT Device_1 = Driver_1->DeviceObject;
	if (!Device_1)
	{
		DbgPrint("Ѱ���豸ʧ��\n");
		NTSTATUS sta = IoCreateDevice(pDriver, 0, Device_NAME,
			FILE_DEVICE_UNKNOWN,
			FILE_DEVICE_SECURE_OPEN, 
			FALSE,//��ʵ���ö�ռ����
			&Device_1);
		if (!NT_SUCCESS(sta))
		{
			DbgPrint("�����豸ʧ��\n");
			return STATUS_SUCCESS;
		}
		Driver_1->DeviceObject = Device_1;
		IoCreateSymbolicLink(pu, Device_NAME);
		return STATUS_SUCCESS;
	}
	else
	{
		UNICODE_STRING Device_NULL = { 0 };
		RtlInitUnicodeString(&Device_NULL, L"\\Device\\Null");
		NTSTATUS sta = IoCreateSymbolicLink(pu, &Device_NULL);
		if (!NT_SUCCESS(sta))
		{
			DbgPrint("�ҷ�������ʧ��");
			return STATUS_SUCCESS;
		}
	}
	//
	//
	EDIT_R3_DLL_DOS(ntdll, pu, ep);
	//
	char shellcode[] = {
	0x55,
	0x8B,0xEC,
	0x83,0xEC,0x40,
	0xFF,0x75,0x0C,
	0xFF,0x75,0x08,
	0x53,
	0xB8,0x34,0x12,0x00,0x00,//14
	0xBB,0x78,0x56,0x00,0x00,//19
	0xC1,0xE0,0x10,
	0x09,0xD8,
	0x5B,
	0xFF,0xD0,
	0x83,0xC4,0x40,
	0x5D,
	0xC2,0x08,0x00 };
	ULONG_PTR a = Find_DLL_Space(Driver_1->DriverStart,sizeof(shellcode));
	DbgPrint("%x", a);
	if (a == 0)
	{
		DbgPrint("�����ڴ�ʧ��\n");
		return STATUS_SUCCESS;
	}
	else
	{
		//�޸�shellcode
		ULONG_PTR low = (ULONG_PTR)Main_DISPATCH & 0xFFFF;
		ULONG_PTR high = ((ULONG_PTR)Main_DISPATCH >> 0x10) & 0xFFFF;
		*(PULONG)&shellcode[14] = high;
		*(PULONG)&shellcode[19] = low;
		//
		//ӳ��
		PHYSICAL_ADDRESS physical_Add=MmGetPhysicalAddress(a);
		PVOID mem=MmMapIoSpace(physical_Add,sizeof(shellcode),MmCached);
		if (mem)
		{
			memcpy(mem, shellcode,sizeof(shellcode));
			MmUnmapIoSpace(mem, sizeof(shellcode));
		}
		Driver_1->MajorFunction[IRP_MJ_DEVICE_CONTROL] = a;
	}
	/*if (LockFile(L"\\??\\C:\\windows\\system32\\drivers\\NULL.SYS"))
	{
		DbgPrint("�ɹ���סţ��\n");
	}*/
	return STATUS_SUCCESS;
}
