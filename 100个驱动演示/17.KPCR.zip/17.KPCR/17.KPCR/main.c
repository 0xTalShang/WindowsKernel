#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}
#define AFFINITY_MASK(n) ((ULONG_PTR)1 << (n))
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	//DbgBreakPoint();
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	//ULONG Number = KeGetCurrentProcessorNumber(); ��׼ȷ
	PROCESSOR_NUMBER pr = { 0 };
	KeGetCurrentProcessorNumberEx(&pr);
	ULONG Number = pr.Number;
	KdPrintEx((77,0,"Number:%x\n", Number));
	ULONG SelfPcr = 0;
	if (Number != 0)
	{
		KdPrintEx((77, 0, "Number:%x\n", Number));
		do 
		{
			KAFFINITY Processors = AFFINITY_MASK(0);
			KeSetSystemAffinityThread(Processors);
			SelfPcr = __readfsdword(0x1c);//+0x01c SelfPcr 			
		} while (*(ULONG*)(SelfPcr + 0x34) == 0);
	}
	else
	{
		SelfPcr = __readfsdword(0x1c);
	}
	CHAR Num = KeNumberProcessors;
	KdPrintEx((77,0,"����������:%x\n", Num));
	if (!SelfPcr) return 0;
	ULONG KdVersionBlock = *(ULONG*)(SelfPcr + 0x34);//�� *((ULONG*)SelfPcr + 0x34) �������һֱΪ0
	if (!KdVersionBlock) return 0;
	ULONG DebuggerDataList = *(ULONG*)(KdVersionBlock + 0x20);
	KdPrintEx((77, 0, "DebuggerDataList:%x\n", DebuggerDataList));
	ULONG TempAddress = *(ULONG*)DebuggerDataList;
	ULONG KiProcessorBlock = *(ULONG*)(TempAddress + 0x218);
	ULONG SizeOfBlock = 0;
	while (*(ULONG*)KiProcessorBlock != 0)
	{
		SizeOfBlock++ ;
		KiProcessorBlock += 4;
	}
	KiProcessorBlock = *(ULONG*)(TempAddress + 0x218);
	for (ULONG i = 0; i < SizeOfBlock; i++)
	{
		KdPrintEx((77, 0, "KPCR:%x\n", (*(ULONG*)KiProcessorBlock) - 0x120));
		KiProcessorBlock += 4;
	}
	return STATUS_SUCCESS;
}
