#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}



PUNICODE_STRING g_Reg = NULL;

VOID Callback(
	_In_ PVOID Parameter
)
{
	UNREFERENCED_PARAMETER(Parameter);
	KdPrintEx((77,0,"ZwUnloadDriver!\n"));
	PWORK_QUEUE_ITEM work = ExAllocatePool(NonPagedPool, sizeof(WORK_QUEUE_ITEM));
	if (!work) return 0;
	ExInitializeWorkItem(work, ZwUnloadDriver, g_Reg);
	ExQueueWorkItem(work, CriticalWorkQueue);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);

	g_Reg = ExAllocatePool(NonPagedPool,sizeof(UNICODE_STRING));
	if (!g_Reg) return 0;
	g_Reg->Buffer=ExAllocatePool(NonPagedPool,pReg->MaximumLength);
	if (!g_Reg->Buffer) return 0;
	g_Reg->Length = pReg->Length;
	g_Reg->MaximumLength = pReg->MaximumLength;
	memcpy(g_Reg->Buffer,pReg->Buffer,pReg->Length);
	g_Reg->Buffer[pReg->Length / 2] = L'\0';

	HANDLE thread = NULL;
	NTSTATUS sta= PsCreateSystemThread(&thread,THREAD_ALL_ACCESS,NULL,NULL,NULL, Callback,NULL);
	if (NT_SUCCESS(sta))
	{
		NtClose(thread);
	}

	return STATUS_SUCCESS;
}
