#include"table.h"
#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
	InitTable();
	InsertTableItem(1,1);
	InsertTableItem(2,2);
	InsertTableItem(3,3);
	InsertTableItem(4,4);
	/*
	PInfo info=LookupTableItem(2);
	if (info)
	{
		KdPrintEx((77,0,"pid:%d,x:%d\n",(int)info->pid,(int)info->x));
	}
	info = LookupTableItem(100);
	if (info)
	{
		KdPrintEx((77, 0, "pid:%d,x:%d\n",(int)info->pid,(int)info->x));
	}
	*/

	DestoryTalbe2();

	return STATUS_SUCCESS;
}
