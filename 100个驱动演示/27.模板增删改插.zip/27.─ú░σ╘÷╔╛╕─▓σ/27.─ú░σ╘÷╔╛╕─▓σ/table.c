#include"table.h"
RTL_GENERIC_TABLE table = { 0 };



RTL_GENERIC_COMPARE_RESULTS NTAPI Compare(
    _In_ struct _RTL_GENERIC_TABLE* Table,
    _In_ PVOID FirstStruct,
    _In_ PVOID SecondStruct
)
{
    PInfo info = (PInfo)FirstStruct;
    PInfo myinfo = (PInfo)SecondStruct;
    if (info->pid > myinfo->pid)
    {
        return GenericGreaterThan;
    }
    else if (info->pid < myinfo->pid)
    {
        return GenericLessThan;
    }
    else
    {
        return GenericEqual;
    }

}

PVOID NTAPI Allocate(
    _In_ struct _RTL_GENERIC_TABLE* Table,
    _In_ CLONG ByteSize
)
{
    return ExAllocatePool(NonPagedPool, ByteSize);
}

VOID NTAPI Free(
    _In_ struct _RTL_GENERIC_TABLE* Table,
    _In_ __drv_freesMem(Mem) _Post_invalid_ PVOID Buffer
)
{
    ExFreePool(Buffer);
}

VOID InitTable()
{
	RtlInitializeGenericTable(&table, Compare, Allocate, Free,NULL);
}

BOOLEAN InsertTableItem(ULONG64 pid, ULONG64 x)
{
    Info info = { 0 };
    info.pid = pid;
    info.x = x;
    BOOLEAN isNew = FALSE;
    RtlInsertElementGenericTable(&table, &info,sizeof(Info),&isNew);
    return isNew;
}

PInfo LookupTableItem(ULONG64 pid)
{
    Info info;
    info.pid = pid;
    return (PInfo)RtlLookupElementGenericTable(&table,&info);
}

BOOLEAN DeleteTableItem(ULONG64 pid)
{
    if (!RtlIsGenericTableEmpty(&table))
    {
        Info info;
        info.pid = pid;
        RtlDeleteElementGenericTable(&table,&info);
        return TRUE;
    }
    return FALSE;
}

BOOLEAN DestoryTable()
{
    PInfo info = NULL;
    PInfo key = NULL;
    while ((info = RtlEnumerateGenericTableWithoutSplaying(&table, &key))!=NULL )
    {
        key = NULL;
        RtlDeleteElementGenericTable(&table, info);
    }
    if (RtlIsGenericTableEmpty(&table))
    {
        return TRUE;
    }
    return FALSE;
}
VOID DestoryTalbe2()
{
    ULONG num = RtlNumberGenericTableElements(&table);
    for (int i = 0; i < (int)num; i++)
    {
        PInfo info = RtlEnumerateGenericTable(&table, TRUE);//TRUE ������0��ʼ1 2 3���Ρ�
        KdPrintEx((77, 0, "pid:%d,x:%d\n", (int)info->pid, (int)info->x));
        RtlDeleteElementGenericTable(&table,info);
    }
}