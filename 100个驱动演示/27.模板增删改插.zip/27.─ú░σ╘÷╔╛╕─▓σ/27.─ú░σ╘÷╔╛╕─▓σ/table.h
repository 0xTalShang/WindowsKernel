#pragma once
#include"ntifs.h"
typedef struct _Info
{
    ULONG64 pid;
    ULONG64 x;
}Info, * PInfo;
VOID InitTable();
BOOLEAN InsertTableItem(ULONG64 pid,ULONG64 x);
PInfo LookupTableItem(ULONG64 pid);
BOOLEAN DeleteTableItem(ULONG64 pid);
BOOLEAN DestoryTable();
VOID DestoryTalbe2();