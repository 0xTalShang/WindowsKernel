#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);

	PEPROCESS ep = 0;
	HANDLE Pid = (HANDLE)2496;
	NTSTATUS sta=PsLookupProcessByProcessId(Pid,&ep);
	if (!NT_SUCCESS(sta)) return 0;;
	PLIST_ENTRY CurrentSection = (PLIST_ENTRY)((ULONG)ep + 0x02c);
	PLIST_ENTRY NextSection = CurrentSection->Blink;
	while (CurrentSection!= NextSection)
	{
		ULONG KTHREAD = (ULONG)NextSection - 0x1e0;
		KdPrintEx((77,0,"dt _KPROCESS:%x\n", KTHREAD));
		RemoveEntryList(NextSection);
		NextSection = NextSection->Blink;
	}
	return STATUS_SUCCESS;
}
