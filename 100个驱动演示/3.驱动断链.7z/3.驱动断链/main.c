#include<ntifs.h>
NTKERNELAPI NTSTATUS ObReferenceObjectByName(
    __in PUNICODE_STRING ObjectName,
    __in ULONG Attributes,
    __in_opt PACCESS_STATE AccessState,
    __in_opt ACCESS_MASK DesiredAccess,
    __in POBJECT_TYPE ObjectType,
    __in KPROCESSOR_MODE AccessMode,
    __inout_opt PVOID ParseContext,
    __out PVOID* Object
);
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	DbgPrint("%z,%d,%d\r\n", __FUNCTION__, __LINE__, __TIME__);
}
extern POBJECT_TYPE* IoDriverObjectType;
PDRIVER_OBJECT FindDriverObject(wchar_t* name)
{
    UNICODE_STRING DriverName;
    RtlInitUnicodeString(&DriverName, name);
    PDRIVER_OBJECT pDriverObject = 0;
    NTSTATUS status = ObReferenceObjectByName(&DriverName,OBJ_CASE_INSENSITIVE,0,0,*IoDriverObjectType,KernelMode,0,&pDriverObject);
    if (!NT_SUCCESS(status))
    {
        KdPrint(("status:%x\n",status));
        return 0;
    }
    if (pDriverObject)
    {
        ObDereferenceObject(pDriverObject);//���ü���-1������볤�ó��ж�����д�˺�����
    }
    return pDriverObject;
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
    FindDriverObject(L"\\Driver\\pchunter32as");
	return STATUS_SUCCESS;
}
