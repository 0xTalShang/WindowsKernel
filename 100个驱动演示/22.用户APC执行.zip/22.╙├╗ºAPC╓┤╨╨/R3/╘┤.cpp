#include<windows.h>
#include<stdio.h>

void WINAPI ApcFunc(PVOID context, PVOID system2, PVOID System2)
{
	printf("ApcFunc ����!\n");
}

int main()
{
	printf("ApcFunc:0x%x ����ID:%d\n",(ULONG)ApcFunc,GetCurrentProcessId());
	while (1)
	{
		Sleep(1000);
	}

	return 0;
}