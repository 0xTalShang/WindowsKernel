#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);
}

typedef enum _KAPC_ENVIRONMENT {
    OriginalApcEnvironment,
    AttachedApcEnvironment,
    CurrentApcEnvironment,
    InsertApcEnvironment
} KAPC_ENVIRONMENT;
typedef VOID (*PKNORMAL_ROUTINE) (
    IN PVOID NormalContext,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
    );
typedef VOID (*PKKERNEL_ROUTINE) (
    IN struct _KAPC* Apc,
    IN OUT PKNORMAL_ROUTINE* NormalRoutine,
    IN OUT PVOID* NormalContext,
    IN OUT PVOID* SystemArgument1,
    IN OUT PVOID* SystemArgument2
    );
typedef VOID (*PKRUNDOWN_ROUTINE) (
    IN struct _KAPC* Apc);

NTKERNELAPI VOID KeInitializeApc(
    __out PRKAPC Apc,
    __in PRKTHREAD Thread,
    __in KAPC_ENVIRONMENT Environment,
    __in PKKERNEL_ROUTINE KernelRoutine,
    __in_opt PKRUNDOWN_ROUTINE RundownRoutine,
    __in_opt PKNORMAL_ROUTINE NormalRoutine,
    __in_opt KPROCESSOR_MODE ProcessorMode,
    __in_opt PVOID NormalContext
);
NTKERNELAPI BOOLEAN KeInsertQueueApc(
    __inout PRKAPC Apc,
    __in_opt PVOID SystemArgument1,
    __in_opt PVOID SystemArgument2,
    __in KPRIORITY Increment
);

VOID KERNEL_ROUTINE(
    IN struct _KAPC* Apc,
    IN OUT PKNORMAL_ROUTINE* NormalRoutine,
    IN OUT PVOID* NormalContext,
    IN OUT PVOID* SystemArgument1,
    IN OUT PVOID* SystemArgument2
)
{
    //DbgBreakPoint();
    UNREFERENCED_PARAMETER(Apc);
    UNREFERENCED_PARAMETER(NormalRoutine);
    UNREFERENCED_PARAMETER(SystemArgument1);
    UNREFERENCED_PARAMETER(SystemArgument2);
    // *NormalRoutine= xxxx �ٳ���
    //ȡ����Apc->NormalContext������ȡ��������
    KdPrintEx((77, 0, "KERNEL_ROUTINE NormalContext:%x\n", (ULONG)*NormalContext));
}
 BOOLEAN KeAlertThread(
    __inout PKTHREAD Thread,
    __in KPROCESSOR_MODE AlertMode
);
PETHREAD GetThreadID(PEPROCESS ep)
{
    HANDLE PID = PsGetProcessId(ep);
    for (int i = 8; i < 0x1000000; i += 4)
    {
        PETHREAD thread = NULL;
        NTSTATUS sta = PsLookupThreadByThreadId((HANDLE)i, &thread);
        if (!NT_SUCCESS(sta))
        {
            continue;
        }
        ObDereferenceObject(thread);

        HANDLE pid = PsGetThreadProcessId(thread);
        if (PID == pid)
        {
            //�ж��Ƿ����û��߳�
            //+0x218 StartAddress : Ptr32 Void
            if (*(ULONG*)((ULONG)thread + 0x218) < 0x80000000)
            {
                return thread;
            }
        }     
    }
    return NULL;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
    //DbgBreakPoint();
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);
    PKAPC kapc = ExAllocatePool(NonPagedPool,sizeof(KAPC));
    if (!kapc) return 0;
    memset(kapc, 0, sizeof(KAPC));

    PEPROCESS ep=NULL;
    NTSTATUS sta = PsLookupProcessByProcessId((HANDLE)2240 ,&ep);
    if (!NT_SUCCESS(sta)) return sta;
    PETHREAD thread=GetThreadID(ep);
    if (!thread)
    {
        KdPrintEx((77,0,"��ȡR3�߳�ʧ��\n"));
        return sta;
    }
    KdPrintEx((77, 0, "R3�߳�_ETHREAD %x\n",(ULONG)thread));

    KeInitializeApc(
        kapc,
        thread,
        OriginalApcEnvironment,
        KERNEL_ROUTINE,
        NULL,
        (PKNORMAL_ROUTINE)0x401000,
        UserMode,
        NULL
    );

    BOOLEAN flag=KeInsertQueueApc(
        kapc,
        NULL,
        NULL,
        0
    );
    if (!flag)
    {
        ExFreePool(kapc);
    }
    else 
    {
        ((PKAPC_STATE)((ULONG)thread + 0x40))->UserApcPending = 1;
        KeAlertThread(thread, UserMode);
    }
	return STATUS_SUCCESS;
}
