#include"irp.h"
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;
HANDLE h_Device = Open();
int main()
{
	
	DATA inbuf = { 0 };
	DATA outbuf = { 0 };
	DWORD ret_Byte = 0;
	BOOL is = 0;
	if (h_Device)
	{
		is = DeviceIoControl(h_Device, CT_TEST, &inbuf, sizeof(inbuf), &outbuf, sizeof(inbuf), &ret_Byte, 0);
	}
	if (is)
	{
		cout << inbuf.DATA << endl<<outbuf.DATA<<endl;
	}
	CloseHandle(h_Device);
	system("pause");
	return 0;
}
