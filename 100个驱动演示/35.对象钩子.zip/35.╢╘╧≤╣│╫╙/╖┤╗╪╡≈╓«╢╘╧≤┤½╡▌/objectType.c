#include "objectType.h"


HANDLE pidProtect = 2600;
HANDLE NotepadPID = 2516;
OB_PREOP_CALLBACK_STATUS preProcessCall(
	_In_ PVOID RegistrationContext,
	_Inout_ POB_PRE_OPERATION_INFORMATION OperationInformation
	)
{

	PEPROCESS Notepad = NULL;
	PsLookupProcessByProcessId(NotepadPID, &Notepad);
	if (!Notepad) return 0;
	
	if (OperationInformation->KernelHandle) return 0;

	PEPROCESS aimPro=NULL;
	PsLookupProcessByProcessId(pidProtect,&aimPro);
	if (!aimPro) return 0;

	if (OperationInformation->Object != aimPro) return 0;
	if (OperationInformation->Object == Notepad)
	{
		DbgBreakPoint();
	}


	OperationInformation->Object = Notepad;

	return OB_PREOP_SUCCESS;
}

PVOID registerHandle=0;
BOOLEAN initProtectProcess()
{
	//DbgBreakPoint();

	OB_CALLBACK_REGISTRATION objRegisterInfo = { 0 };
	objRegisterInfo.Version = ObGetFilterVersion();
	objRegisterInfo.OperationRegistrationCount = 1;
	objRegisterInfo.RegistrationContext = NULL;
	UNICODE_STRING Altitude;
	RtlInitUnicodeString(&Altitude,L"33332");
	objRegisterInfo.Altitude= Altitude;

	OB_OPERATION_REGISTRATION operation = { 0 };
	operation.ObjectType = PsProcessType;
	operation.Operations = OB_OPERATION_HANDLE_CREATE | OB_OPERATION_HANDLE_DUPLICATE;
	operation.PreOperation = preProcessCall;
	operation.PostOperation = NULL;

	objRegisterInfo.OperationRegistration = &operation;


	NTSTATUS sta=ObRegisterCallbacks(&objRegisterInfo,&registerHandle);
	if (!NT_SUCCESS(sta))
	{
		return FALSE;
	}
	return TRUE;
}

VOID CloseProtectProcess()
{
	if (registerHandle)
	{
		ObUnRegisterCallbacks(registerHandle);
	}
}