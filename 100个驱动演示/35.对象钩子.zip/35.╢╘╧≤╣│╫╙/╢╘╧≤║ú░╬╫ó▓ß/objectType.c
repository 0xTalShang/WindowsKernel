#include "objectType.h"


HANDLE pidProtect = 176;

OB_PREOP_CALLBACK_STATUS preProcessCall(
	_In_ PVOID RegistrationContext,
	_Inout_ POB_PRE_OPERATION_INFORMATION OperationInformation
	)
{
	if (OperationInformation->KernelHandle) return 0;

	PEPROCESS aimPro=NULL;
	PsLookupProcessByProcessId(pidProtect,&aimPro);
	if (!aimPro) return 0;

	if (OperationInformation->Object != aimPro) return 0;

	OperationInformation->Parameters->CreateHandleInformation.DesiredAccess = PROCESS_ALL_ACCESS;
	OperationInformation->Parameters->DuplicateHandleInformation.DesiredAccess = PROCESS_ALL_ACCESS;

	return OB_PREOP_SUCCESS;
}

PVOID registerHandle=0;
BOOLEAN initProtectProcess()
{
	//DbgBreakPoint();

	OB_CALLBACK_REGISTRATION objRegisterInfo = { 0 };
	objRegisterInfo.Version = ObGetFilterVersion();
	objRegisterInfo.OperationRegistrationCount = 1;
	objRegisterInfo.RegistrationContext = NULL;
	UNICODE_STRING Altitude;
	RtlInitUnicodeString(&Altitude,L"33332");
	objRegisterInfo.Altitude= Altitude;

	OB_OPERATION_REGISTRATION operation = { 0 };
	operation.ObjectType = PsProcessType;
	operation.Operations = OB_OPERATION_HANDLE_CREATE | OB_OPERATION_HANDLE_DUPLICATE;
	operation.PreOperation = preProcessCall;
	operation.PostOperation = NULL;

	objRegisterInfo.OperationRegistration = &operation;


	NTSTATUS sta=ObRegisterCallbacks(&objRegisterInfo,&registerHandle);
	if (!NT_SUCCESS(sta))
	{
		return FALSE;
	}
	return TRUE;
}

VOID CloseProtectProcess()
{
	if (registerHandle)
	{
		ObUnRegisterCallbacks(registerHandle);
	}
}