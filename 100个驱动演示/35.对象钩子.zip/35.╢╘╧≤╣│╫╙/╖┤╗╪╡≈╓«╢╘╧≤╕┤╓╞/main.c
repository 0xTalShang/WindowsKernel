#include<ntifs.h>

VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{

}

HANDLE pid = NULL;
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;

	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId(pid,&ep);
	if (!ep) return 0;




	return STATUS_SUCCESS;
}
