#pragma once
#include<ntifs.h>
BOOLEAN initProtectProcess();
VOID CloseProtectProcess();