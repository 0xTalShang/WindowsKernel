#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	DbgPrint("%z,%d,%d\r\n", __FUNCTION__, __LINE__, __TIME__);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;

	return STATUS_SUCCESS;
}
