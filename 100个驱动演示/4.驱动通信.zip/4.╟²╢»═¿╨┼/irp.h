#pragma once
#include<ntifs.h>
typedef struct
{
	ULONG Type;
	ULONG Result;//ע��ṹ����ֽڶ���
	ULONG64 data;
	ULONG64 size;

}DATA,* PDATA;
typedef NTSTATUS(NTAPI* CallBack)(PDATA data);
BOOLEAN Register(PDRIVER_OBJECT pDriver, CallBack callback);
VOID UnRegister(PDRIVER_OBJECT pDriver);