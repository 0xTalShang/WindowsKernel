#include"irp.h"
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UnRegisterFunction(DriverObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	BOOLEAN is = RegisterFunction(pDriver);
	if (is == TRUE)
	{
		KdPrint(("ע��ɹ���"));
	}
	return STATUS_SUCCESS;
}
