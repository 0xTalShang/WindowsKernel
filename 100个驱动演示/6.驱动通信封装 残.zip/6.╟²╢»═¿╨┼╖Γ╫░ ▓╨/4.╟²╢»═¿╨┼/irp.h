#pragma once
#include <ntifs.h>
typedef struct
{
	ULONG TYPE;
	ULONG RESULT;
	ULONG64 DATA;
	ULONG64 SIZE;
}DATA, * PDATA;
typedef NTSTATUS(NTAPI* CallBack_Func)(PDATA pdata);
BOOLEAN RegisterFunction(PDRIVER_OBJECT pDriver);
VOID UnRegisterFunction(PDRIVER_OBJECT pDriver);