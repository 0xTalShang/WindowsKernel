#include"IO.h"
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	UNICODE_STRING SymbolName = { 0 };
	RtlInitUnicodeString(&SymbolName, L"\\??\\RwSymbol");
	IoDeleteSymbolicLink(&SymbolName);
	IoDeleteDevice(DriverObject->DeviceObject);
}
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	UNREFERENCED_PARAMETER(pReg);

	DbgBreakPoint();
	//TsCreateDeviceIo(pDriver);	

	return STATUS_SUCCESS;
}
