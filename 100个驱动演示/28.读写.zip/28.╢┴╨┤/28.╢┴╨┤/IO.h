#pragma once
#include"ntifs.h"
#define CODE CTL_CODE(FILE_DEVICE_UNKNOWN,0x800,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
* 0�� 1д 2ȡx64ģ�� 3ȡx86ģ��
*/
typedef struct _DATA
{
	ULONG64 Type;
	ULONG64 Pid;
	ULONG64 BaseAddress; 
    ULONG64 Size;
	ULONG64 Buffer;
	char*   ModuleName;
}DATA,*PDATA;
PDEVICE_OBJECT TsCreateDeviceIo(PDRIVER_OBJECT pDriver);

ULONG64 TsReadProcessMemory(ULONG64 Pid, ULONG64 BaseAddress, ULONG64 Size, ULONG64 Buffer);
ULONG64 TsWriteProcessMemory(ULONG64 Pid, ULONG64 BaseAddress, ULONG64 Size, ULONG64 Buffer);

ULONG64 TsGetHmodule64(ULONG64 Pid,char* ModuleName);
ULONG32 TsGetHomdule32(ULONG32 Pid,char* ModuleName);

ULONG64 TsVirtualAlloc64(ULONG64 Pid,ULONG32 Size);
ULONG64 TsVirtualAlloc2(ULONG64 Pid,ULONG32 Size,PMDL* pmdl);
BOOLEAN TsVirtualFree2(ULONG64 Mem,PMDL mdl);