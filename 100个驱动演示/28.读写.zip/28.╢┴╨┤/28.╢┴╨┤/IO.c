#include"IO.h"
NTSTATUS Open(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp
)
{
	Irp->IoStatus.Status = STATUS_SUCCESS;
	IoCompleteRequest(Irp,0);
	//DbgPrintEx(77, 0, "Open\n");
	return STATUS_SUCCESS;
}
NTSTATUS Close(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp
)
{
	Irp->IoStatus.Status = STATUS_SUCCESS;
	IoCompleteRequest(Irp, 0);
	//DbgPrintEx(77, 0, "Close\n");
	return STATUS_SUCCESS;
}

NTSTATUS Control(
	_In_ struct _DEVICE_OBJECT* DeviceObject,
	_Inout_ struct _IRP* Irp
)
{
	//DbgBreakPoint();
	//PIO_STACK_LOCATION pio=IoGetCurrentIrpStackLocation(Irp);
	//ULONG Code=pio->Parameters.DeviceIoControl.IoControlCode;
	PDATA data=(PDATA)Irp->AssociatedIrp.SystemBuffer;
	switch(data->Type)
	{
		case 0:
		{
		ULONG64 ret=TsReadProcessMemory(
					data->Pid,
					data->BaseAddress,
					data->Size,
					data->Buffer);
		data->Size = ret;
		Irp->IoStatus.Information = sizeof(DATA);
		break;
		}

		case 1:
		{
		ULONG64 ret=TsWriteProcessMemory(
					data->Pid,
					data->BaseAddress,
					data->Size,
					data->Buffer
				);
		data->Size = ret;
		Irp->IoStatus.Information = sizeof(DATA);
		break;
		}

		case 2:
		{
			ULONG64 Hmodule=TsGetHmodule64(data->Pid,data->ModuleName);
			data->Size= Hmodule;
			Irp->IoStatus.Information = sizeof(DATA);
			break;
		}

		case 3:
		{
			ULONG32 Hmodule =TsGetHomdule32((ULONG32)data->Pid,data->ModuleName);
			data->Size = Hmodule;
			Irp->IoStatus.Information = sizeof(DATA);
			break;
		}

		case 4:
		{
			ULONG64 address=TsVirtualAlloc64(data->Pid, (ULONG32)data->Size);
			data->Size = address;
			Irp->IoStatus.Information = sizeof(DATA);
			break;
		}

		case 5:
		{
			DbgBreakPoint();
			PMDL mdl;
			ULONG64 address = TsVirtualAlloc2(data->Pid,(ULONG32)data->Size,&mdl);
			data->Size = address;
			Irp->IoStatus.Information = sizeof(DATA);
			break;
		}
	}
	Irp->IoStatus.Status = STATUS_SUCCESS;
	IoCompleteRequest(Irp, 0);
	return STATUS_SUCCESS;
}



PDEVICE_OBJECT TsCreateDeviceIo(PDRIVER_OBJECT pDriver)
{
	UNICODE_STRING DeviceName = { 0 };
	RtlInitUnicodeString(&DeviceName, L"\\Device\\RWDevice");
	PDEVICE_OBJECT pdevice = NULL;
	NTSTATUS sta = IoCreateDevice(
		pDriver,
		0,
		&DeviceName,
		FILE_DEVICE_UNKNOWN,
		FILE_DEVICE_SECURE_OPEN,
		TRUE,
		&pdevice);
	if (!NT_SUCCESS(sta)) return 0;
	UNICODE_STRING SymbolName = { 0 };
	RtlInitUnicodeString(&SymbolName, L"\\??\\RwSymbol");
	sta = IoCreateSymbolicLink(&SymbolName, &DeviceName);
	if (!NT_SUCCESS(sta)) return 0;
	pdevice->Flags |= DO_BUFFERED_IO;
	pDriver->MajorFunction[IRP_MJ_CLOSE] = Close;
	pDriver->MajorFunction[IRP_MJ_CREATE] = Open;
	pDriver->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Control;

	return pdevice;
}

ULONG64 TsReadProcessMemory(ULONG64 Pid, ULONG64 BaseAddress, ULONG64 Size, ULONG64 Buffer)
{
	PEPROCESS ep = NULL;
	NTSTATUS sta=PsLookupProcessByProcessId((HANDLE)Pid,&ep);
	if (!NT_SUCCESS(sta)) return 0;
	

	if (BaseAddress > MmUserProbeAddress || (BaseAddress + Size) > MmUserProbeAddress)
	{
		return 0;
	}


	PVOID64 mem=ExAllocatePool(NonPagedPool, Size);
	if (!mem) return 0;
	RtlZeroMemory(mem,Size);

	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep,&apc);
	if ( !MmIsAddressValid((PVOID64)BaseAddress) || !MmIsAddressValid( (PVOID64)(BaseAddress + Size) ) )
	{
		ExFreePool(mem);
		ObDereferenceObject(ep);
		return 0;
	}
	memcpy(mem, (PVOID64)BaseAddress, Size);
	KeUnstackDetachProcess(&apc);
	memcpy((PVOID64)Buffer, mem, Size);
	ExFreePool(mem);
	ObDereferenceObject(ep);
	return Size;
}

ULONG64 TsWriteProcessMemory(ULONG64 Pid, ULONG64 BaseAddress, ULONG64 Size, ULONG64 Buffer)
{
	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId((HANDLE)Pid, &ep);
	if (!ep) return 0;
	ObDereferenceObject(ep);

	if (BaseAddress > MmUserProbeAddress || (BaseAddress + Size) > MmUserProbeAddress)
	{
		return 0;
	}


	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep, &apc);

	if (!MmIsAddressValid((PVOID64)BaseAddress) || !MmIsAddressValid((PVOID64)(BaseAddress + Size)))
	{
		return 0;
	}

	PMDL mdl=IoAllocateMdl((PVOID)BaseAddress,(ULONG)Size,FALSE,FALSE,NULL);
	MmProbeAndLockPages(mdl, UserMode, IoReadAccess);
	PVOID mem=MmMapLockedPagesSpecifyCache(mdl,KernelMode,MmNonCached,NULL,FALSE,NormalPagePriority);
	if (!mem)
	{
		MmUnlockPages(mdl);
		IoFreeMdl(mdl);
		KeUnstackDetachProcess(&apc);
		return 0;
	}
	KeUnstackDetachProcess(&apc);
	memcpy(mem, (PVOID)Buffer, Size);

	MmUnmapLockedPages(mem, mdl);
	MmUnlockPages(mdl);
	IoFreeMdl(mdl);
	return Size;
}


PVOID64 NTAPI PsGetProcessPeb(PEPROCESS ep);
typedef struct _PEB_LDR_DATA
{
	ULONG32 Length;                                                           //0x0
	ULONG32 Initialized;                                                      //0x4
	ULONG64 SsHandle;                                                         //0x8
    LIST_ENTRY64 InLoadOrderModuleList;                               //0x10
}PEB_LDR,*PPEB_LDR;
typedef struct _LDR_DATA_TABLE_ENTRY
{
	LIST_ENTRY64 InLoadOrderLinks;                                    //0x0
	LIST_ENTRY64 InMemoryOrderLinks;                                  //0x10
	LIST_ENTRY64 InInitializationOrderLinks;                          //0x20
	PULONG64     DllBase;                                                   //0x30
	PULONG64     EntryPoint;                                                //0x38
	PULONG64     SizeOfImage;                                               //0x40
	UNICODE_STRING64 FullDllName;                                     //0x48
	UNICODE_STRING64 BaseDllName;                                     //0x58
}LDR_DATA_ENTRY,*PLDR_DATA_ENTRY;
ULONG64 TsGetHmodule64(ULONG64 Pid, char* ModuleName)
{
	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId((HANDLE)Pid, &ep);
	if (!ep) return 0;
	if (!ModuleName) return 0;

	ANSI_STRING nameA = { 0 };
	RtlInitAnsiString(&nameA,ModuleName);
	UNICODE_STRING nameW = {0};
	RtlAnsiStringToUnicodeString(&nameW, &nameA, TRUE);


	PVOID64 peb=PsGetProcessPeb(ep);
	if (!peb) return 0;


	KAPC_STATE apc = { 0 };

	KeStackAttachProcess(ep, &apc);

	PVOID64 Ldr = (PVOID64) * (ULONG64*)((ULONG64)peb + 0x18);
	if (!Ldr) return 0;

	PPEB_LDR ldr = (PPEB_LDR)Ldr;
	PLDR_DATA_ENTRY firstEntry = (PLDR_DATA_ENTRY)ldr->InLoadOrderModuleList.Flink;
	PLDR_DATA_ENTRY ldrEntry = (PLDR_DATA_ENTRY)(&ldr->InLoadOrderModuleList.Flink);
	while (firstEntry != ldrEntry)
	{
		PUNICODE_STRING firstName = (PUNICODE_STRING)&firstEntry->BaseDllName;
		if (RtlCompareUnicodeString(firstName, &nameW, TRUE) == 0)
		{
			ULONG64 Hmodule = (ULONG64)firstEntry->DllBase;
			KeUnstackDetachProcess(&apc);
			ObDereferenceObject(ep);
			RtlFreeUnicodeString(&nameW);
			return Hmodule;
		}
		firstEntry = (PLDR_DATA_ENTRY)firstEntry->InLoadOrderLinks.Flink;
	}

	KeUnstackDetachProcess(&apc);
	ObDereferenceObject(ep);
	RtlFreeUnicodeString(&nameW);
	return 0;
}


#pragma pack(4)
PVOID64 __fastcall PsGetProcessWow64Process(PEPROCESS ep);
typedef struct _PEB_LDR_DATA32
{
	ULONG Length;                                                           //0x0
	UCHAR Initialized;                                                      //0x4
	ULONG32 SsHandle;                                                         //0x8
	LIST_ENTRY32 InLoadOrderModuleList;                               //0xc
	LIST_ENTRY32 InMemoryOrderModuleList;                             //0x14
	LIST_ENTRY32 InInitializationOrderModuleList;                     //0x1c
	ULONG32 EntryInProgress;                                                  //0x24
	UCHAR ShutdownInProgress;                                               //0x28
	ULONG32 ShutdownThreadId;                                                 //0x2c
}PEB_LDR_DATA32,*PPEB_LDR_DATA32;
typedef struct _LDR_DATA_ENTRY32
{
	LIST_ENTRY32 InLoadOrderLinks;                                    //0x0
	LIST_ENTRY32 InMemoryOrderLinks;                                  //0x8
	LIST_ENTRY32 InInitializationOrderLinks;                          //0x10
	ULONG32 DllBase;                                                  //0x18
	ULONG32 EntryPoint;                                               //0x1c
	ULONG32 SizeOfImage;                                              //0x20
	UNICODE_STRING32 FullDllName;                                     //0x24
	UNICODE_STRING32 BaseDllName;                                     //0x2c
}PLDR_DATA_ENTRY32,*PPLDR_DATA_ENTRY32;
#pragma pack()
ULONG32 TsGetHomdule32(ULONG32 Pid, char* ModuleName)
{
	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId((HANDLE)Pid, &ep);
	if (!ep) return 0;
	if (!ModuleName) return 0;

	ANSI_STRING nameA = { 0 };
	RtlInitAnsiString(&nameA, ModuleName);
	UNICODE_STRING nameW = { 0 };
	RtlAnsiStringToUnicodeString(&nameW, &nameA, TRUE);

	PVOID64 PEB32=PsGetProcessWow64Process(ep);//��ȡpeb
	if (!PEB32) return 0;

	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep, &apc);
	PULONG32 Ldr= (PULONG32)*(ULONG32*)((ULONG64)PEB32 + 0xC);//Ldr

	PPEB_LDR_DATA32 ldr = (PPEB_LDR_DATA32)Ldr;
	PPLDR_DATA_ENTRY32 firstEntry = (PPLDR_DATA_ENTRY32)(&ldr->InLoadOrderModuleList.Flink);
	PPLDR_DATA_ENTRY32 secondEntry = (PPLDR_DATA_ENTRY32)ldr->InLoadOrderModuleList.Flink;
	UNICODE_STRING name;
	while (secondEntry != firstEntry)
	{
		RtlInitUnicodeString(&name, (PCWSTR)secondEntry->BaseDllName.Buffer);
		if (RtlCompareUnicodeString(&name, &nameW, TRUE) == 0)
		{
			ULONG32 Hmodule = secondEntry->DllBase;
			KeUnstackDetachProcess(&apc);
			ObDereferenceObject(ep);
			RtlFreeUnicodeString(&nameW);
			return Hmodule;
		}
		secondEntry = (PPLDR_DATA_ENTRY32)secondEntry->InLoadOrderLinks.Flink;
	}
	KeUnstackDetachProcess(&apc);
	ObDereferenceObject(ep);
	RtlFreeUnicodeString(&nameW);
	return 0;
}


BOOLEAN SetThreadPreviousMode(PKTHREAD thread, MODE Mode, MODE* oldMode)
{
	MODE mode=ExGetPreviousMode();
	*oldMode = mode;
	ULONG64 pmode = (ULONG64)ExGetPreviousMode;
	ULONG32 offest = 0;
	for (int i = 0; i<100;i++)
	{
		if( *((PUCHAR)(pmode + i)) == 0xC3 )
		{
			if (*((PUCHAR)(pmode + i - 1)) == 0x00)
			{
				pmode = pmode + i - 4;
				pmode = *(PULONG64)pmode;
				offest = (ULONG32)pmode;
				break;
			}
		}
	}
	if (pmode == (ULONG64)ExGetPreviousMode)
	{
		return FALSE;
	}
	*(PUCHAR)((ULONG64)thread + offest) = Mode;
	return TRUE;
}

ULONG64 TsVirtualAlloc64(ULONG64 Pid, ULONG32 Size)
{
	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId((HANDLE)Pid, &ep);
	if (!ep) return 0;

	MODE oldMode;
	BOOLEAN flag = SetThreadPreviousMode(KeGetCurrentThread(),KernelMode,&oldMode);
	if (flag == FALSE) return FALSE;

	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep, &apc);
	PVOID64 baseAddress = 0;
	SIZE_T size = (SIZE_T)Size;
	NtAllocateVirtualMemory(
		NtCurrentProcess(),
		&baseAddress,
		0,
		&size,
		MEM_COMMIT| MEM_RESERVE,
		PAGE_READWRITE
	);
	KeUnstackDetachProcess(&apc);

	SetThreadPreviousMode(KeGetCurrentThread(),oldMode, &oldMode);
	ObDereferenceObject(ep);
	return (ULONG64)baseAddress;
}

ULONG64 TsVirtualAlloc2(ULONG64 Pid, ULONG32 Size,PMDL* pmdl)
{
	PEPROCESS ep = NULL;
	PsLookupProcessByProcessId((HANDLE)Pid, &ep);
	if (!ep) return 0;

	PVOID64 mem = ExAllocatePool(NonPagedPool,(SIZE_T)Size);
	if (!mem) return 0;

	ULONG64 address = 0;

	KAPC_STATE apc = { 0 };
	KeStackAttachProcess(ep, &apc);

	PMDL mdl=IoAllocateMdl(mem,Size,FALSE,FALSE,NULL);
	*pmdl = mdl;
	MmProbeAndLockPages(mdl,KernelMode,IoReadAccess);
	PVOID64 mapMem=MmMapLockedPagesSpecifyCache(mdl,UserMode,MmNonCached,0,0,NormalPagePriority);
	address = (ULONG64)mapMem;
	KeUnstackDetachProcess(&apc);

	ObDereferenceObject(ep);
	return address;
}
BOOLEAN TsVirtualFree2(ULONG64 Mem,PMDL mdl)
{
	MmUnlockPages(mdl);
	MmUnmapLockedPages((PVOID64)Mem,mdl);
	IoFreeMdl(mdl);
	return TRUE;
}