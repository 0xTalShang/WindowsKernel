#pragma once
#include<windows.h>

ULONG64 WINAPI TsReadProcessMemory(HANDLE Pid, PVOID BaseAddress, ULONG Size, PVOID Buffer);
ULONG64 WINAPI TsWriteProcessMemory(HANDLE Pid, PVOID BaseAddress, ULONG Size, PVOID Buffer);
ULONG64 WINAPI TsGetHmodule64(ULONG64 Pid, char* ModuleName);
ULONG32 WINAPI TsGetHomdule32(ULONG32 Pid, char* ModuleName);
ULONG64 WINAPI TsVirtualAlloc64(ULONG64 Pid, ULONG32 Size);
ULONG32 WINAPI TsVirtualAlloc32(ULONG32 Pid, ULONG32 Size);
ULONG64 WINAPI TsVirtualAlloc264(ULONG64 Pid,ULONG32 Size);
ULONG32 WINAPI TsVirtualAlloc232(ULONG32 Pid,ULONG32 Size);