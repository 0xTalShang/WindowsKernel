#include<stdio.h>
#include<windows.h>
#include"rw.h"
#define SymblName L"\\\\.\\RwSymbol"
extern HANDLE hDevice;
int main()
{
	hDevice = CreateFileW(
		SymblName,
		GENERIC_READ | GENERIC_WRITE,
		NULL,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if (!hDevice) return 0;

	TsVirtualAlloc264(2140, 0x1000);
	/*ULONG32 a = 0;
	ULONGLONG time1=GetTickCount64();
	for (int i = 0; i <= 1000000; i++)
	{
		TsReadProcessMemory((HANDLE)2796, (PVOID)0x00848000, 4, &a);
	}
	ULONGLONG time2 = GetTickCount64();
	printf("%x ",a);
	printf("\nʱ��:%d\n", (int)(time2 - time1));*/

	system("pause");
	return 0;
}