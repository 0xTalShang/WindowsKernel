#include "rw.h"
#define CODE CTL_CODE(FILE_DEVICE_UNKNOWN,0x800,METHOD_BUFFERED,FILE_ANY_ACCESS)
typedef struct _DATA
{
	ULONG64 Type;
	ULONG64 Pid;
	ULONG64 BaseAddress;
	ULONG64 Size;
	ULONG64 Buffer;
	char* ModuleName;
}DATA, * PDATA;
HANDLE hDevice=0;
ULONG64 WINAPI TsReadProcessMemory(HANDLE Pid, PVOID BaseAddress, ULONG Size, PVOID Buffer)
{
	DATA data;
	data.Pid = (ULONG64)Pid;
	data.BaseAddress = (ULONG64)BaseAddress;
	data.Size = (ULONG64)Size;
	data.Type = 0;
	data.Buffer = (ULONG64)Buffer;	
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	//CloseHandle(hDevice);
	return data.Size;
}
ULONG64 WINAPI TsWriteProcessMemory(HANDLE Pid, PVOID BaseAddress, ULONG Size, PVOID Buffer)
{
	return 0;
}
ULONG64 WINAPI TsGetHmodule64(ULONG64 Pid, char* ModuleName)
{
	DATA data = {0};
	data.Pid = (ULONG64)Pid;
	data.Type = 2;
	data.ModuleName = ModuleName;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return data.Size;
}
ULONG32 WINAPI TsGetHomdule32(ULONG32 Pid, char* ModuleName)
{
	DATA data = { 0 };
	data.Pid = (ULONG64)Pid;
	data.Type = 3;
	data.ModuleName = ModuleName;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return (ULONG32)data.Size;
}
ULONG64 WINAPI TsVirtualAlloc64(ULONG64 Pid, ULONG32 Size)
{
	DATA data = { 0 };
	data.Pid = (ULONG64)Pid;
	data.Type = 4;
	data.Size = Size;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return (ULONG64)data.Size;
}
ULONG32 WINAPI TsVirtualAlloc32(ULONG32 Pid, ULONG32 Size)
{
	DATA data = { 0 };
	data.Pid = (ULONG64)Pid;
	data.Type = 4;
	data.Size = Size;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return (ULONG32)data.Size;
}
ULONG64 WINAPI TsVirtualAlloc264(ULONG64 Pid, ULONG32 Size)
{
	DATA data = { 0 };
	data.Pid = (ULONG64)Pid;
	data.Type = 5;
	data.Size = Size;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return (ULONG64)data.Size;
}
ULONG32 WINAPI TsVirtualAlloc232(ULONG32 Pid, ULONG32 Size)
{
	DATA data = { 0 };
	data.Pid = (ULONG64)Pid;
	data.Type = 5;
	data.Size = Size;
	ULONG ret;
	DeviceIoControl(
		hDevice,
		CODE,
		&data,
		sizeof(data),
		&data,
		sizeof(data),
		&ret,
		0
	);
	return (ULONG32)data.Size;
}