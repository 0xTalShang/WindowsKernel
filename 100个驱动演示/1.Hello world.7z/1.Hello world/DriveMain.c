#include<ntifs.h>
VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
}
int a = 1;
NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;// ��
	//DbgPrint("Hello World!\n");
	//DbgPrint("ȫ�ֱ���:%x\n",a);
	return STATUS_SUCCESS;
}
