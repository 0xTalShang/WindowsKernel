#include<ntifs.h>


HANDLE createFile(wchar_t* path) //ע��ر��ļ����
{
	HANDLE hFile = NULL;
	OBJECT_ATTRIBUTES OBJ = { 0 };
	UNICODE_STRING unFileName = { 0 };
	RtlInitUnicodeString(&unFileName, path);
	InitializeObjectAttributes(
		&OBJ,
		&unFileName,
		OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
		NULL,
		NULL);
	IO_STATUS_BLOCK IoStack = { 0 };//����һ���ļ���״̬
	NTSTATUS sta = ZwCreateFile(
		&hFile,
		FILE_ALL_ACCESS,
		&OBJ,
		&IoStack,
		NULL,    
		FILE_ATTRIBUTE_NORMAL,
		0,
		FILE_OPEN_IF,
		FILE_NON_DIRECTORY_FILE,
		0,
		0);
	if (!NT_SUCCESS(sta))
	{
		DbgPrintEx(77,0,"���ļ�ʧ��\n");
		return 0;
	}
	if (hFile == NULL)
	{
		DbgPrintEx(77,0,"�ļ����ΪNULL\n");
		return 0;
	}
	return hFile;
}

BOOLEAN writeFile(HANDLE filehandle,PVOID buffer,ULONG64 len)
{
	IO_STATUS_BLOCK ioBlock = { 0 };
	LARGE_INTEGER byteOffest = { 0 };
	NTSTATUS sta=ZwWriteFile(
		filehandle,
		0,
		0,
		0,
		&ioBlock,
		buffer,
		(ULONG)len,
		&byteOffest,
		0);
	if (!NT_SUCCESS(sta))
	{
		DbgPrintEx(77, 0, "д���ļ�ʧ��\n");
		return FALSE;
	}
	return TRUE;
}

VOID loadCallback(
	_In_opt_ PUNICODE_STRING FullImageName,
	_In_ HANDLE ProcessId,//������ڼ�������������            
	_In_ PIMAGE_INFO ImageInfo
)
{
	if (ImageInfo->SystemModeImage)
	{
		if (ImageInfo->ImageSize == 0x00115000)
		{
			DbgBreakPoint();
			HANDLE file = NULL;
			file=createFile(L"\\??\\C:\\Windows\\̫��dump�ļ�.sys");
			if (file != NULL)
			{
				BOOLEAN isWrite=writeFile(file,(PVOID)ImageInfo->ImageBase,(ULONG64)ImageInfo->ImageSize);
				if (isWrite)
				{
					DbgPrintEx(77, 0, "д���ļ��ɹ�\n");
				}
			}
			NtClose(file);
		}	
		//DbgPrintEx(77, 0, "����id:%d,FullImageName:%wZ\n",(int)ProcessId,FullImageName);
		//DbgPrintEx(77, 0, "ģ���ַ:0x%x,ģ���С:0x%x\n",(INT64)ImageInfo->ImageBase,(INT64)ImageInfo->ImageSize);
	}
	else
	{
		//PVOID64 addr;
		//ZwAllocateVirtualMemory(NtCurrentProcess(),&addr,NULL,0x1000,MEM_COMMIT,PAGE_READWRITE);
	}
	
}

VOID DRIVERUNLOAD(_In_ struct _DRIVER_OBJECT* DriverObject)
{
	PsRemoveLoadImageNotifyRoutine(loadCallback);
}


NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{
	pDriver->DriverUnload = DRIVERUNLOAD;
	
	PsSetLoadImageNotifyRoutine(loadCallback);

	return STATUS_SUCCESS;
}
