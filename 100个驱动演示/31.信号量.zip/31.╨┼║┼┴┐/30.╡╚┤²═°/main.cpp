#include<windows.h>
#include<stdio.h>

HANDLE Semaphore;
DWORD ThreadFunc(PVOID CONTEXT)
{
	WaitForSingleObject(Semaphore,-1);
	printf("666\n");
	return 0;
}
int main()
{
	Semaphore = CreateSemaphoreA(NULL,0,3,NULL);
	for (int i = 0; i < 3; i++)
	{
		CreateThread(NULL, NULL, ThreadFunc, NULL, NULL, NULL);
	}
	system("pause");
	LONG PreviousCount;
	ReleaseSemaphore(Semaphore,1,&PreviousCount);
	printf("%d", PreviousCount);
	system("pause");
	return 0;
}