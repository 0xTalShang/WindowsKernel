#include "Install.h"
#include "HexFile.h"
BOOLEAN TsWriteFile(char** FilePath)
{
	char directory[0x200] = { 0 };
	GetCurrentDirectoryA(0x200, directory);

	ULONGLONG randNumber=GetTickCount64();

	char *mem=(char*)malloc(0x200);
	if (!mem) return FALSE;
	memset(mem,0,0x200);
	wsprintfA(mem,"%s\\%x.sys",directory,(int)randNumber);

	HANDLE hFile=CreateFileA(mem,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if (!hFile) return FALSE;
	DWORD sizeWrite;
	BOOLEAN flag=WriteFile(hFile,hexData,sizeof(hexData),&sizeWrite,NULL);
	while (sizeWrite != sizeof(hexData))
	{
		int i = 0;
		i++;
	}
	if (!flag)
	{
		CloseHandle(hFile);
		return FALSE;
	}
	CloseHandle(hFile);
	*FilePath = mem;
	return TRUE;
}

BOOLEAN TsLoadDriver(char* FilePath,char** ServiceName)
{
	SC_HANDLE hSc=OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (!hSc) return FALSE;

	ULONGLONG randNumber = GetTickCount64();
	char* nameService = (char*)malloc(0x10);
	if (!nameService) return FALSE;
	memset(nameService, 0, 0x10);
	memcpy(nameService,&randNumber,8);
	SC_HANDLE hService=CreateServiceA(hSc,
		nameService,
		nameService,
		SC_MANAGER_ALL_ACCESS,
		SERVICE_KERNEL_DRIVER,
		SERVICE_DEMAND_START,
		SERVICE_ERROR_IGNORE,
		FilePath,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL
	);
	if (!hService)
	{
		CloseServiceHandle(hSc);
		return FALSE;
	}
	BOOLEAN flag=StartServiceA(hService,0,0);
	if (!flag) return FALSE;
	CloseServiceHandle(hSc);
	CloseServiceHandle(hService);
	*ServiceName =nameService;
	return TRUE;
}

VOID TsUnLoadDriver(char* FilePath, char* ServiceName)
{
	SC_HANDLE hSc = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (!hSc) return;
	SC_HANDLE hService = OpenServiceA(hSc,ServiceName,SC_MANAGER_ALL_ACCESS);
	if (!hService) return;
	SERVICE_STATUS sta;
	ControlService(hService, SERVICE_CONTROL_STOP,&sta);
	DeleteService(hService);
	CloseServiceHandle(hSc);
	return;
}