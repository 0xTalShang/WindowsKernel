#include "Install.h"
#include <stdio.h>
int main(int argc, char* argv[])
{
	__asm
	{
		int 3;
	}
	BOOLEAN flag = FALSE;

	char* FilePath=NULL;
	flag=TsWriteFile(&FilePath);
	if (!flag) return 0;

	char* ServiceName = NULL;
	flag=TsLoadDriver(FilePath,&ServiceName);
	if (!flag) return 0;

	//TsUnLoadDriver(FilePath,ServiceName);
	free(FilePath);
	free(ServiceName);

	system("pause");
	return 0;
}