#pragma once
#include<windows.h>


BOOLEAN TsWriteFile(char** FilePath);
BOOLEAN TsLoadDriver(char* FilePath, char** ServiceName);
VOID TsUnLoadDriver(char* FilePath, char* ServiceName);